package com.vishu.vplayer

/**
 * UI ke saare size (dp) yahin se badalte hain. Koi bhi number badlo, poori app me badal jaayega.
 *
 * PLAYER SCREEN (upar se neeche):
 *   TOP BAR      : [ic_back]  Title ..........................
 *   (beech me)   : video / gestures (swipe, double tap)
 *   [unlock]     : sirf lock ke time, right side beech me
 *   BOTTOM BAR   : 00:00 ........................... 46:45      <- time row
 *                  =========o============================      <- seekbar (orange)
 *                  [subtitles][rotate]   (PLAY)   [aspect][more]  <- 5 buttons
 *
 * 3-dot (ic_more) ke andar: Lock, PiP, Audio track, Speed, Sleep timer,
 *                           Shuffle, Repeat, Subtitle file, Subtitle delay,
 *                           Audio delay, Equalizer
 *
 * LIBRARY SCREEN:
 *   Header : logo + "VPlayer" ............ [ic_more]
 *   Tabs   : [ic_video Videos] [ic_music Music] [ic_history Recent]
 *   Search : ic_search + box
 *   List   : har row me ic_video ya ic_music_file + naam + detail
 *   Mini   : gaane ka naam ............... [ic_play / ic_pause]
 */
object Ui {
    // VLC jaisa: icon 24dp, touch area 48dp
    const val BTN = 48
    const val ICON = 24

    // play / pause bada button
    const val PLAY_BTN = 56
    const val PLAY_ICON = 44

    // library ke chhote hisse
    const val MINI_BTN = 44
    const val TAB_ICON = 20
    const val ROW_ICON = 24
    const val SEARCH_ICON = 20

    // OSD (swipe karte time screen pe dikhne wala text)
    const val OSD_ICON = 28

    // 3-dot menu ki har line
    const val MENU_ROW_H = 52
    const val MENU_ICON = 24

    // player ke bars
    const val BAR_ALPHA = 170          // 0 = bilkul clear, 255 = pura kala
    const val BAR_PAD_H = 12
    const val BAR_PAD_TOP = 6
    const val BAR_PAD_BOTTOM = 10
    const val TIME_TEXT_SP = 13f
    const val TITLE_TEXT_SP = 16f

    // audio file chalne pe beech ka bada music icon
    const val AUDIO_ART = 160
}
