# Eve — Free Mock Test App (Android)

Government/entrance exam mock-test app. Kotlin, MVVM, Firebase (Auth + Firestore),
no custom backend. Built phase-by-phase with Claude.

**This is Phase 1 of the build.** It contains the project skeleton, Gradle
dependencies, Firebase setup instructions, and the core data models. UI screens
(Login, Home, Test, Result, Admin) come in later phases — see
`docs/PHASE_2_PROMPT.md` for the exact next prompt.

## What's in this zip

```
eve-app/
├── build.gradle.kts               (project-level)
├── settings.gradle.kts
├── gradle.properties
├── .gitignore
├── app/
│   ├── build.gradle.kts           (all dependencies: Firebase, Coroutines, MVVM, ViewPager2...)
│   ├── google-services.json       (PLACEHOLDER — replace with your real one, see docs/)
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/eve/mocktest/data/model/
│       │   ├── Exam.kt
│       │   ├── Question.kt        (also contains UserAnswer)
│       │   └── AppConstants.kt    (admin email, collection names)
│       └── res/values/
│           ├── strings.xml        (needs your default_web_client_id)
│           ├── colors.xml
│           └── themes.xml
└── docs/
    ├── FIREBASE_SETUP.md          (do this FIRST, step by step)
    └── PHASE_2_PROMPT.md          (copy-paste to continue the build)
```

## How to use this

### Option A — Open directly in Android Studio
1. Unzip.
2. Android Studio → **Open** → select the `eve-app` folder.
3. Follow `docs/FIREBASE_SETUP.md` (replace the placeholder `google-services.json`,
   set `default_web_client_id` in `strings.xml`).
4. Let Gradle sync. It'll fail on missing Activities until Phase 2 is added —
   that's expected at this stage.

### Option B — Push to GitHub first, then clone/open
```bash
cd eve-app
git init
git add .
git commit -m "Phase 1: project skeleton, Firebase setup, data models"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
Then clone it wherever you want to build (Android Studio, Codemagic, GitHub
Actions with an Android build workflow, etc.) — GitHub itself doesn't compile
APKs for you, so you'll still open it in Android Studio or wire up a CI
workflow (e.g. `gradle assembleDebug` in a GitHub Actions `.yml`) to get an
actual APK.

### Continuing the build
Copy the text from `docs/PHASE_2_PROMPT.md` and send it as your next message
to keep going — Phase 2 adds the Repository layer, Login screen, and Home
screen (exam list).
