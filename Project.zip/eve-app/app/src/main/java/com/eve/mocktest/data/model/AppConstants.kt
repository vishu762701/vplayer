package com.eve.mocktest.data.model

/**
 * App-wide constants.
 *
 * Admin check logic (Phase 2 will use this):
 * FirebaseAuth.currentUser?.email == AppConstants.ADMIN_EMAIL
 *
 * In production, move this list to a Firestore "admins" collection or
 * Firebase Remote Config so you don't have to rebuild the app to add
 * a new admin. For MVP, a hardcoded check is fine.
 */
object AppConstants {
    const val ADMIN_EMAIL = "admin@eve.com"

    const val COLLECTION_EXAMS = "exams"
    const val COLLECTION_QUESTIONS = "questions"

    const val DEFAULT_TIME_LIMIT_MINUTES = 30
}
