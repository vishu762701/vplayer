package com.eve.mocktest.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName

/**
 * Represents a single document in the Firestore "exams" collection.
 *
 * IMPORTANT (Firestore rules):
 * - No-arg constructor with default values is REQUIRED for Firestore's
 *   automatic deserialization (toObject<Exam>()) to work.
 * - @DocumentId automatically injects the Firestore document ID into this field
 *   — do NOT store the ID as a normal field inside the document itself.
 */
data class Exam(
    @DocumentId
    val examId: String = "",

    @PropertyName("examName")
    val examName: String = "",

    @PropertyName("timeLimitMinutes")
    val timeLimitMinutes: Int = 30,

    // Optional but useful for the Home Screen list (icon/category grouping etc.)
    @PropertyName("totalQuestions")
    val totalQuestions: Int = 0,

    @PropertyName("category")
    val category: String = "" // e.g. "SSC", "UPSC", "Banking"
)
