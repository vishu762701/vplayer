package com.eve.mocktest.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName

/**
 * Represents a single document in the Firestore "questions" collection.
 *
 * correctAnswer stores one of: "A", "B", "C", "D"
 * — matching against optionA/B/C/D keeps the schema simple and avoids
 * needing a separate map structure.
 */
data class Question(
    @DocumentId
    val questionId: String = "",

    @PropertyName("examId")
    val examId: String = "",

    @PropertyName("questionText")
    val questionText: String = "",

    @PropertyName("optionA")
    val optionA: String = "",

    @PropertyName("optionB")
    val optionB: String = "",

    @PropertyName("optionC")
    val optionC: String = "",

    @PropertyName("optionD")
    val optionD: String = "",

    // "A" | "B" | "C" | "D"
    @PropertyName("correctAnswer")
    val correctAnswer: String = ""
) {
    /**
     * Helper: returns list of options in order, useful for binding
     * directly to the 4 RadioButtons in the Test Screen without
     * repeating optionA/B/C/D access logic in the UI layer.
     */
    fun optionsList(): List<String> = listOf(optionA, optionB, optionC, optionD)
}

/**
 * NOT stored in Firestore — this is a local/in-memory model used by the
 * ViewModel during the test to track what the student selected for each
 * question as they swipe back and forth in the ViewPager2.
 *
 * selectedOption values: null (unattempted), "A", "B", "C", or "D"
 */
data class UserAnswer(
    val questionId: String,
    var selectedOption: String? = null
)
