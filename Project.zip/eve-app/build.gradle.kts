// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
    id("org.jetbrains.kotlin.kapt") version "1.9.24" apply false
}

// Ensure repositories are resolved correctly across all modules
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
