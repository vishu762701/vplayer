# Firebase Setup — Eve (Mock Test App)

Follow these steps in order. Do this BEFORE opening the project in Android Studio,
or the build will fail (it needs `google-services.json`).

## 1. Create the Firebase Project
1. Go to https://console.firebase.google.com/
2. Click **Add project** → name it `Eve` (or anything) → disable Google Analytics
   if you don't need it (optional, either is fine).

## 2. Register the Android App
1. In the Firebase console, click the **Android icon** to add an app.
2. **Android package name:** `com.eve.mocktest` (must match `applicationId` in
   `app/build.gradle.kts` exactly).
3. App nickname: `Eve` (optional).
4. **Debug signing certificate SHA-1** (REQUIRED for Google Sign-In to work):
   - Run this in your project root (once you have Android Studio + the project open):
     ```
     ./gradlew signingReport
     ```
   - Copy the `SHA1` value under the `debug` variant and paste it into the Firebase
     console field.
5. Download **`google-services.json`** and place it at:
   ```
   app/google-services.json
   ```
   (This repo currently has a placeholder file at that path — replace it with your
   real downloaded file. Never commit your real one to a public GitHub repo if the
   project is public; add it to `.gitignore` if needed.)

## 3. Enable Authentication
1. Firebase console → **Build → Authentication → Get started**.
2. Under **Sign-in method**, enable **Google**.
3. Set a support email (required by Google).
4. Save.

## 4. Enable Firestore Database
1. Firebase console → **Build → Firestore Database → Create database**.
2. Choose **Start in test mode** for now (MVP/dev only — see security rules below
   before you actually launch publicly).
3. Pick a region close to your users (e.g. `asia-south1` for India).

## 5. Firestore Collections (create manually or let the Admin Panel create them)
You do NOT need to pre-create these — Firestore creates a collection the first
time you write a document to it. But for reference, the schema is:

### `exams` collection
| Field             | Type   | Example          |
|--------------------|--------|------------------|
| examName           | String | "SSC CGL Tier 1" |
| timeLimitMinutes   | Number | 30               |
| totalQuestions     | Number | 25               |
| category           | String | "SSC"            |

### `questions` collection
| Field          | Type   | Example                          |
|----------------|--------|-----------------------------------|
| examId         | String | (the document ID of an exam)      |
| questionText   | String | "What is the capital of India?"   |
| optionA        | String | "Mumbai"                          |
| optionB        | String | "New Delhi"                       |
| optionC        | String | "Kolkata"                         |
| optionD        | String | "Chennai"                         |
| correctAnswer  | String | "B"                                |

## 6. Firestore Security Rules (IMPORTANT — do this before real users touch it)
Test mode rules expire after 30 days and are wide open. Replace with something
like this once Phase 2/3 auth is wired up (Admin write, everyone read):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    match /exams/{examId} {
      allow read: if true;
      allow write: if request.auth != null &&
                      request.auth.token.email == "admin@eve.com";
    }

    match /questions/{questionId} {
      allow read: if true;
      allow write: if request.auth != null &&
                      request.auth.token.email == "admin@eve.com";
    }
  }
}
```

## 7. Add your OAuth Web Client ID (needed for Google Sign-In code in Phase 2)
1. Firebase console → Authentication → Sign-in method → Google → expand it →
   copy the **Web client ID** (looks like `xxxxx.apps.googleusercontent.com`).
2. You'll paste this into `strings.xml` as `default_web_client_id` in Phase 2 —
   note it down now.

---
Once all 7 steps are done, you're ready for **Phase 2**.
