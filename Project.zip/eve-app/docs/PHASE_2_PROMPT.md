Copy-paste this as your next message to move to Phase 2:

---

We're continuing the "Eve" mock test app (Phase 1 gave us build.gradle setup,
Firebase setup docs, and the Exam/Question/UserAnswer data models under
com.eve.mocktest.data.model — assume that all exists).

Now give me Phase 2: UI and MVVM setup. Specifically:

1. The Repository layer (FirestoreRepository.kt) with suspend functions /
   Flow to fetch exams and questions from Firestore, using the collections
   and field names from Phase 1's data models.
2. The AuthRepository.kt for Google Sign-In + admin email check
   (using AppConstants.ADMIN_EMAIL).
3. LoginActivity.kt + its XML layout — Google Sign-in button, on success
   navigate to HomeActivity, unlock Admin Dashboard button if
   FirebaseAuth.currentUser?.email == AppConstants.ADMIN_EMAIL.
4. HomeActivity.kt + XML layout + HomeViewModel.kt — RecyclerView of exams
   (ExamAdapter.kt), tapping an exam starts TestActivity.
5. Keep it modular — separate files, don't cram everything into one Activity.

Do NOT do the Test Screen (ViewPager2), Result Screen, or Admin Dashboard yet
— that's Phase 3 and Phase 4. Give me the exact prompt for Phase 3 at the end
of your response, same as before.

---
