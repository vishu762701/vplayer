# EVE / VPlayer - project notes (naye chat ke liye handoff)

**Naye chat me Claude ko ye zip do aur bolo:** "NOTES.md padh ke wahin se aage badho."

## Kya hai
- Android video/music player. Engine = libvlc (VLC ka engine, `org.videolan.android:libvlc-all:3.6.0`), UI apna (Kotlin, bina XML - sab code me).
- Ye VLC ka official app / fork nahi hai. App me About screen hai (LGPL credit). VLC ka naam/cone logo use nahi karna.
- User coding nahi jaanta. Har cheez step-by-step, Hinglish me, ready files/zip ke roop me deni hai.
- Build: GitHub Actions (repo me `project.zip` upload -> workflow build karta hai -> Actions > Artifacts > APK).
  Workflow file repo me `.github/workflows/build.yml` hai (zip ke andar nahi).
- Naya zip hamesha `project.zip` naam se do, root me `app/`, `tools/`, `build.gradle.kts`... (koi extra folder nahi).

## Files ka map
| Kya badalna hai | Kahan |
|---|---|
| Saare sizes / gap / text size / app naam ("EVE") | `app/src/main/java/com/vishu/vplayer/Ui.kt` |
| Main page ka layout (toolbar, grid, nav) | `MainActivity.kt` -> `buildLibrary()` |
| Folder / video card ka design | `MainActivity.kt` -> `makeCard()`, `gridAdapter` |
| Thumbnail loading | `MainActivity.kt` -> `loadThumb()`, `makeThumb()` |
| Player screen | `MainActivity.kt` -> `buildPlayer()` |
| Icons | `app/src/main/res/drawable/ic_*.xml` (SVG se `tools/svg2vd.py` se bane) |
| App icon / logo | `res/mipmap-*`, `res/drawable-nodpi/logo.png`, `ic_launcher_foreground.png` |
| Permissions / launcher naam | `AndroidManifest.xml` |
| Background music notification | `PlayService.kt` |

## Colors
orange `#EE8331`, bg `#131313`, nav/mini `#2A2A2A`, gray `#C4C4C4` (MainActivity.kt ke upar `orange`, `bg`, `surface`, `iconGray`).

## Ab tak ho gaya
- Player: gestures, lock, PiP, audio/subtitle track, speed, sleep timer, equalizer, resume, shuffle/repeat, background audio.
- Main page (VLC ke screenshot se naapa): toolbar [logo] eve + search + resume + 3-dot, top tabs VIDEOS|PLAYLISTS, folder cards (2x2 mosaic thumbnail, naam, "N videos", 3-dot), folder kholo = video cards (thumbnail + duration), orange FAB (play all), bottom nav Video|Audio|Browse|Playlists|More.
  - Browse = Open file + Network stream. More = History, Sort by, Clear history, About. Playlists abhi khali ("No playlists yet").
  - Colors VLC screenshot se: orange #EE8331, bg #131313, nav #2A2A2A, gray #C4C4C4. Naam "eve" (chhote akshar) = `Ui.APP_NAME`.
  - Naye icons ke SVG source `svg/` folder me (ic_tb_*, ic_nav_*, ic_card_more, ic_fab_play); logo ka tight crop `res/drawable-nodpi/logo_crop.png`.

## Kaam ka tareeka (user ne tay kiya)
- Ek baar me ek page. Pehle main page, phir agla page (user batayega).
- User VLC ka screenshot deta hai; usi ke hisab se same style + same distance rakhna hai.
- Build error aaye toh user Actions ka error screenshot/text bhejta hai -> fix karke naya zip.

## Agla
- User se main page ka result dekhna (screenshot) aur spacing fine-tune karna (`Ui.kt` ke numbers).
- Phir agla page (user bolega). Audio page abhi simple list hai.
