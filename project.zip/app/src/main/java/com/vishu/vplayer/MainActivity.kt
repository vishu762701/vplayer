package com.vishu.vplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ContentUris
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import kotlin.math.abs

data class Item(
    val uri: Uri,
    val title: String,
    val sub: String,
    val audio: Boolean,
    val added: Long,
    val size: Long,
    val dur: Long
)

class MainActivity : Activity() {

    companion object {
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        const val REQ_OPEN = 1
        const val REQ_SUB = 2
        const val REQ_PERM = 3
    }

    private val orange = Color.parseColor("#FF8800")
    private val bg = Color.parseColor("#121212")
    private val surface = Color.parseColor("#1E1E1E")

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private var pfd: ParcelFileDescriptor? = null
    private var attached = false

    // ---------- library views ----------
    private lateinit var root: FrameLayout
    private lateinit var library: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    private lateinit var tabButtons: Array<Button>
    private lateinit var miniBar: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: Button

    // ---------- player views ----------
    private lateinit var playerScreen: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var audioArt: TextView
    private lateinit var touchLayer: View
    private lateinit var topBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var controls: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var playBtn: Button
    private lateinit var shuffleBtn: Button
    private lateinit var repeatBtn: Button
    private lateinit var speedBtn: Button
    private lateinit var osd: TextView
    private lateinit var unlockBtn: Button

    // ---------- state ----------
    private var tab = 0
    private var sortMode = 0
    private var allItems: List<Item> = emptyList()
    private var shownItems: List<Item> = emptyList()
    private var queue: List<Item> = emptyList()
    private var qIndex = -1
    private var current: Item? = null
    private var shuffle = false
    private var repeatMode = 0
    private var locked = false
    private var pendingSeek = 0L
    private var lastSave = 0L
    private var length = 0L
    private var userSeeking = false
    private var sleepRunnable: Runnable? = null
    private var orientMode = 0
    private var scaleIdx = 0
    private var volPct = 100
    private var pendingView: Uri? = null

    // gesture state
    private var gestureMode = 0
    private var startTime = 0L
    private var startBright = 0.5f
    private var startVol = 100
    private var seekTarget = 0L

    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
    private val scaleNames = arrayOf("Best fit", "Fit screen", "Fill", "16:9", "4:3", "Original")
    private val sortNames = arrayOf("Newest", "Name", "Size")

    private val hideOsd = Runnable { osd.visibility = View.GONE }
    private val hideRunnable = Runnable {
        if (player.isPlaying && current?.audio != true && !locked) showControls(false)
    }

    private lateinit var gd: GestureDetector

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shownItems.size
        override fun getItem(position: Int): Any = shownItems[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: makeRow()
            val item = shownItems[position]
            (row.getChildAt(0) as TextView).text = (if (item.audio) "♪  " else "▶  ") + item.title
            (row.getChildAt(1) as TextView).text = item.sub
            return row
        }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("vplayer", MODE_PRIVATE)
        libVLC = LibVLC(
            this,
            arrayListOf("--no-drop-late-frames", "--no-skip-frames", "--network-caching=1500")
        )
        player = MediaPlayer(libVLC)

        window.statusBarColor = bg
        window.navigationBarColor = bg

        root = FrameLayout(this)
        root.setBackgroundColor(bg)
        buildLibrary()
        buildPlayer()
        root.addView(library, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(playerScreen, FrameLayout.LayoutParams(MATCH, MATCH))
        playerScreen.visibility = View.GONE
        setContentView(root)

        player.setEventListener(MediaPlayer.EventListener { e ->
            runOnUiThread { onPlayerEvent(e) }
        })

        refreshTabs()
        ensurePermission()

        if (intent?.action == Intent.ACTION_VIEW) pendingView = intent.data
    }

    override fun onStart() {
        super.onStart()
        if (playerScreen.visibility == View.VISIBLE && !attached) {
            player.attachViews(videoLayout, null, true, false)
            attached = true
        }
        pendingView?.let {
            handleViewUri(it)
            pendingView = null
        }
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        if (current?.audio != true) player.pause()
        if (attached) {
            player.detachViews()
            attached = false
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_VIEW) intent.data?.let { handleViewUri(it) }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (playerScreen.visibility == View.VISIBLE && player.isPlaying && current?.audio != true) {
            enterPip()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (playerScreen.visibility == View.VISIBLE) leavePlayer() else super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        saveProgress()
        handler.removeCallbacksAndMessages(null)
        stopBgService()
        try {
            player.stop()
            player.release()
            libVLC.release()
            pfd?.close()
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Permissions and library
    // =====================================================================

    private fun needPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun ensurePermission() {
        val need = needPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) loadLibrary() else requestPermissions(need.toTypedArray(), REQ_PERM)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        loadLibrary()
    }

    private fun loadLibrary() {
        val t = tab
        Thread {
            val list: List<Item> = when (t) {
                0 -> queryMedia(true)
                1 -> queryMedia(false)
                else -> loadRecent()
            }
            runOnUiThread {
                allItems = list
                applyFilter()
            }
        }.start()
    }

    private fun queryMedia(video: Boolean): List<Item> {
        val out = ArrayList<Item>()
        try {
            val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val durCol = if (video) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION
            val proj = arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                durCol,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_ADDED
            )
            contentResolver.query(base, proj, null, null, null)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(durCol)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext()) {
                    val dur = c.getLong(iDur)
                    if (!video && dur < 20000L) continue
                    val name = c.getString(iName) ?: "?"
                    val size = c.getLong(iSize)
                    out.add(
                        Item(
                            ContentUris.withAppendedId(base, c.getLong(iId)),
                            name.substringBeforeLast('.'),
                            fmt(dur) + "  •  " + humanSize(size),
                            !video,
                            c.getLong(iAdded),
                            size,
                            dur
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim().lowercase()
        var l: List<Item> = if (q.isEmpty()) allItems else allItems.filter { it.title.lowercase().contains(q) }
        if (tab != 2) {
            l = when (sortMode) {
                1 -> l.sortedBy { it.title.lowercase() }
                2 -> l.sortedByDescending { it.size }
                else -> l.sortedByDescending { it.added }
            }
        }
        shownItems = l
        adapter.notifyDataSetChanged()
        emptyText.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun refreshTabs() {
        for (i in tabButtons.indices) {
            tabButtons[i].setTextColor(if (i == tab) orange else Color.GRAY)
            tabButtons[i].setTypeface(null, if (i == tab) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun loadRecent(): List<Item> {
        val raw = prefs.getString("recent", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("\t")
            if (p.size < 3) null
            else Item(Uri.parse(p[0]), p[1], if (p[2] == "1") "Music" else "Video", p[2] == "1", 0L, 0L, 0L)
        }
    }

    private fun pushRecent(item: Item) {
        val key = item.uri.toString()
        val line = key + "\t" + item.title.replace("\t", " ").replace("\n", " ") +
                "\t" + (if (item.audio) "1" else "0")
        val l = ArrayList<String>()
        l.add(line)
        (prefs.getString("recent", "") ?: "").split("\n")
            .filter { it.isNotBlank() && !it.startsWith(key + "\t") }
            .forEach { l.add(it) }
        prefs.edit().putString("recent", l.take(30).joinToString("\n")).apply()
    }

    // =====================================================================
    // UI: library
    // =====================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun makeRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        val a = TextView(this)
        a.setTextColor(Color.WHITE)
        a.textSize = 16f
        a.maxLines = 1
        a.ellipsize = TextUtils.TruncateAt.END
        val b = TextView(this)
        b.setTextColor(Color.GRAY)
        b.textSize = 12f
        b.maxLines = 1
        r.addView(a)
        r.addView(b)
        return r
    }

    private fun flatBtn(label: String): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setTextColor(Color.WHITE)
        return b
    }

    private fun buildLibrary() {
        library = LinearLayout(this)
        library.orientation = LinearLayout.VERTICAL
        library.setBackgroundColor(bg)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(8), dp(8), dp(0))
        val title = TextView(this)
        title.text = "VPlayer"
        title.setTextColor(orange)
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val menu = flatBtn("⋮")
        menu.textSize = 22f
        menu.setOnClickListener { showLibraryMenu(menu) }
        header.addView(menu, LinearLayout.LayoutParams(WRAP, WRAP))
        library.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val names = arrayOf("🎬 Videos", "🎵 Music", "🕘 Recent")
        tabButtons = Array(3) { i ->
            val b = flatBtn(names[i])
            b.setOnClickListener {
                tab = i
                refreshTabs()
                loadLibrary()
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
            b
        }
        library.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))

        searchBox = EditText(this)
        searchBox.hint = "🔍 Search"
        searchBox.setHintTextColor(Color.GRAY)
        searchBox.setTextColor(Color.WHITE)
        searchBox.setSingleLine()
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        val sp = LinearLayout.LayoutParams(MATCH, WRAP)
        sp.setMargins(dp(12), 0, dp(12), 0)
        library.addView(searchBox, sp)

        emptyText = TextView(this)
        emptyText.text = "Kuch nahi mila.\nPermission allow karo ya ⋮ menu se file kholo."
        emptyText.setTextColor(Color.GRAY)
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(dp(16), dp(32), dp(16), dp(16))
        emptyText.visibility = View.GONE
        library.addView(emptyText, LinearLayout.LayoutParams(MATCH, WRAP))

        listView = ListView(this)
        listView.adapter = adapter
        listView.dividerHeight = 0
        listView.setOnItemClickListener { _, _, pos, _ -> startQueue(shownItems, pos) }
        library.addView(listView, LinearLayout.LayoutParams(MATCH, 0, 1f))

        miniBar = LinearLayout(this)
        miniBar.orientation = LinearLayout.HORIZONTAL
        miniBar.gravity = Gravity.CENTER_VERTICAL
        miniBar.setBackgroundColor(surface)
        miniBar.setPadding(dp(16), dp(4), dp(8), dp(4))
        miniTitle = TextView(this)
        miniTitle.setTextColor(Color.WHITE)
        miniTitle.maxLines = 1
        miniTitle.ellipsize = TextUtils.TruncateAt.END
        miniTitle.setOnClickListener { if (current != null) showPlayer() }
        miniBar.addView(miniTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        miniPlay = flatBtn("▶")
        miniPlay.setOnClickListener { togglePlay() }
        miniBar.addView(miniPlay, LinearLayout.LayoutParams(WRAP, WRAP))
        miniBar.visibility = View.GONE
        library.addView(miniBar, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun showLibraryMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "📂 Open file")
        pm.menu.add(0, 2, 1, "🌐 Network stream")
        pm.menu.add(0, 3, 2, "Sort: " + sortNames[sortMode])
        pm.menu.add(0, 4, 3, "🔀 Play all (shuffle)")
        pm.menu.add(0, 5, 4, "🗑 Clear recent")
        pm.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> openPicker()
                2 -> streamDialog()
                3 -> {
                    sortMode = (sortMode + 1) % sortNames.size
                    applyFilter()
                }
                4 -> if (shownItems.isNotEmpty()) {
                    shuffle = true
                    updateModeButtons()
                    startQueue(shownItems, (0 until shownItems.size).random())
                }
                5 -> {
                    prefs.edit().remove("recent").apply()
                    if (tab == 2) loadLibrary()
                }
            }
            true
        }
        pm.show()
    }

    private fun streamDialog() {
        val et = EditText(this)
        et.hint = "http://...  rtsp://...  .m3u8"
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setView(et)
            .setPositiveButton("Play") { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) {
                    val uri = Uri.parse(u)
                    startQueue(listOf(Item(uri, uri.lastPathSegment ?: u, "Stream", false, 0L, 0L, 0L)), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =====================================================================
    // UI: player
    // =====================================================================

    private fun ctlBtn(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setPadding(0, dp(8), 0, dp(8))
        b.setOnClickListener {
            onClick()
            scheduleHide()
        }
        parent.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        return b
    }

    private fun buildPlayer() {
        playerScreen = FrameLayout(this)
        playerScreen.setBackgroundColor(Color.BLACK)

        videoLayout = VLCVideoLayout(this)
        playerScreen.addView(videoLayout, FrameLayout.LayoutParams(MATCH, MATCH))

        audioArt = TextView(this)
        audioArt.text = "♪"
        audioArt.setTextColor(orange)
        audioArt.textSize = 120f
        audioArt.gravity = Gravity.CENTER
        audioArt.visibility = View.GONE
        playerScreen.addView(audioArt, FrameLayout.LayoutParams(MATCH, MATCH))

        touchLayer = View(this)
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = 0
                startTime = player.getTime()
                startBright = currentBrightness()
                startVol = volPct
                seekTarget = startTime
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (!locked) {
                    val show = controls.visibility != View.VISIBLE
                    showControls(show)
                    if (show) scheduleHide()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = touchLayer.width.toFloat()
                if (e.x < w / 3f) seekBy(-10000L)
                else if (e.x > w * 2f / 3f) seekBy(10000L)
                else togglePlay()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null) return true
                val totalX = e2.x - e1.x
                val totalY = e2.y - e1.y
                if (gestureMode == 0) {
                    gestureMode = if (abs(totalX) > abs(totalY)) 1
                    else if (e1.x < touchLayer.width / 2f) 2 else 3
                }
                when (gestureMode) {
                    1 -> {
                        val len = player.getLength()
                        if (len > 0) {
                            var t = startTime + (totalX / touchLayer.width * 120000f).toLong()
                            if (t < 0) t = 0
                            if (t > len) t = len
                            seekTarget = t
                            val diff = (t - startTime) / 1000
                            showOsd(fmt(t) + "  (" + (if (diff >= 0) "+" else "") + diff + "s)")
                        }
                    }
                    2 -> {
                        var b = startBright - totalY / touchLayer.height * 1.5f
                        if (b < 0.02f) b = 0.02f
                        if (b > 1f) b = 1f
                        val lp = window.attributes
                        lp.screenBrightness = b
                        window.attributes = lp
                        showOsd("☀ " + (b * 100).toInt() + "%")
                    }
                    3 -> {
                        var v = startVol - (totalY / touchLayer.height * 250f).toInt()
                        if (v < 0) v = 0
                        if (v > 200) v = 200
                        volPct = v
                        player.setVolume(v)
                        showOsd("🔊 $v%")
                    }
                }
                return true
            }
        })
        touchLayer.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == 1 && !locked) player.setTime(seekTarget)
                gestureMode = 0
            }
            true
        }
        playerScreen.addView(touchLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // top bar
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(Color.argb(170, 0, 0, 0))
        topBar.setPadding(dp(4), dp(4), dp(4), dp(4))
        val back = flatBtn("←")
        back.textSize = 20f
        back.setOnClickListener { leavePlayer() }
        topBar.addView(back, LinearLayout.LayoutParams(WRAP, WRAP))
        titleText = TextView(this)
        titleText.setTextColor(Color.WHITE)
        titleText.maxLines = 1
        titleText.ellipsize = TextUtils.TruncateAt.END
        topBar.addView(titleText, LinearLayout.LayoutParams(0, WRAP, 1f))
        val pip = flatBtn("PiP")
        pip.setOnClickListener { enterPip() }
        topBar.addView(pip, LinearLayout.LayoutParams(WRAP, WRAP))
        playerScreen.addView(
            topBar,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP)
        )

        // OSD
        osd = TextView(this)
        osd.setTextColor(Color.WHITE)
        osd.textSize = 22f
        osd.gravity = Gravity.CENTER
        osd.setBackgroundColor(Color.argb(170, 0, 0, 0))
        osd.setPadding(dp(20), dp(10), dp(20), dp(10))
        osd.visibility = View.GONE
        playerScreen.addView(
            osd,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER)
        )

        // bottom controls
        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setBackgroundColor(Color.argb(170, 0, 0, 0))
        controls.setPadding(dp(8), dp(6), dp(8), dp(10))

        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) timeText.text = fmt(p * 1000L) + " / " + fmt(length)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                userSeeking = false
                player.setTime((s?.progress ?: 0) * 1000L)
            }
        })
        controls.addView(seek)

        timeText = TextView(this)
        timeText.text = "00:00 / 00:00"
        timeText.setTextColor(Color.WHITE)
        timeText.gravity = Gravity.CENTER
        controls.addView(timeText)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        ctlBtn(row1, "🔒") { setLocked(true) }
        ctlBtn(row1, "⏮") { prev() }
        ctlBtn(row1, "-10") { seekBy(-10000L) }
        playBtn = ctlBtn(row1, "▶") { togglePlay() }
        ctlBtn(row1, "+10") { seekBy(10000L) }
        ctlBtn(row1, "⏭") { next() }
        ctlBtn(row1, "⤢") {
            scaleIdx = (scaleIdx + 1) % scaleNames.size
            applyScale(scaleIdx)
        }
        controls.addView(row1)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        shuffleBtn = ctlBtn(row2, "🔀") {
            shuffle = !shuffle
            updateModeButtons()
            showOsd(if (shuffle) "Shuffle ON" else "Shuffle OFF")
        }
        repeatBtn = ctlBtn(row2, "🔁") {
            repeatMode = (repeatMode + 1) % 3
            updateModeButtons()
            showOsd(arrayOf("Repeat OFF", "Repeat ALL", "Repeat ONE")[repeatMode])
        }
        ctlBtn(row2, "🔊") {
            pickTrack("Audio track", player.getAudioTracks(), player.getAudioTrack()) {
                player.setAudioTrack(it)
            }
        }
        ctlBtn(row2, "CC") {
            pickTrack("Subtitles", player.getSpuTracks(), player.getSpuTrack()) {
                player.setSpuTrack(it)
            }
        }
        speedBtn = ctlBtn(row2, "1x") { speedDialog() }
        ctlBtn(row2, "🌙") { sleepDialog() }
        ctlBtn(row2, "⋮") { moreDialog() }
        controls.addView(row2)

        playerScreen.addView(
            controls,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        )

        unlockBtn = Button(this)
        unlockBtn.text = "🔓"
        unlockBtn.setBackgroundColor(Color.argb(170, 0, 0, 0))
        unlockBtn.setTextColor(Color.WHITE)
        unlockBtn.visibility = View.GONE
        unlockBtn.setOnClickListener { setLocked(false) }
        playerScreen.addView(
            unlockBtn,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL)
        )

        updateModeButtons()
    }

    private fun updateModeButtons() {
        shuffleBtn.alpha = if (shuffle) 1f else 0.4f
        repeatBtn.alpha = if (repeatMode == 0) 0.4f else 1f
        repeatBtn.text = if (repeatMode == 2) "🔂" else "🔁"
    }

    private fun showControls(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        controls.visibility = v
        topBar.visibility = v
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 4000L)
    }

    private fun showOsd(text: String) {
        osd.text = text
        osd.visibility = View.VISIBLE
        handler.removeCallbacks(hideOsd)
        handler.postDelayed(hideOsd, 1000L)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun setLocked(l: Boolean) {
        locked = l
        if (l) {
            showControls(false)
            unlockBtn.visibility = View.VISIBLE
            showOsd("🔒 Locked")
        } else {
            unlockBtn.visibility = View.GONE
            showControls(true)
            scheduleHide()
        }
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                ) else 0
    }

    private fun showPlayer() {
        library.visibility = View.GONE
        playerScreen.visibility = View.VISIBLE
        if (!attached) {
            player.attachViews(videoLayout, null, true, false)
            attached = true
        }
        immersive(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showControls(true)
        scheduleHide()
    }

    private fun leavePlayer() {
        saveProgress()
        if (current?.audio != true) {
            player.stop()
            stopBgService()
            current = null
        }
        playerScreen.visibility = View.GONE
        library.visibility = View.VISIBLE
        immersive(false)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        orientMode = 0
        updateMini()
    }

    private fun updateMini() {
        val c = current
        if (c != null && c.audio) {
            miniBar.visibility = View.VISIBLE
            miniTitle.text = "♪  " + c.title
            miniPlay.text = if (player.isPlaying) "⏸" else "▶"
        } else {
            miniBar.visibility = View.GONE
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26 && playerScreen.visibility == View.VISIBLE) {
            showControls(false)
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (e: Exception) {
                Toast.makeText(this, "PiP is phone me nahi chal raha", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // =====================================================================
    // Playback
    // =====================================================================

    private fun onPlayerEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.LengthChanged -> {
                length = e.lengthChanged
                seek.max = (length / 1000).toInt()
            }
            MediaPlayer.Event.TimeChanged -> {
                if (!userSeeking) {
                    seek.progress = (e.timeChanged / 1000).toInt()
                    timeText.text = fmt(e.timeChanged) + " / " + fmt(length)
                }
                val now = System.currentTimeMillis()
                if (now - lastSave > 5000L) {
                    lastSave = now
                    saveProgress()
                }
            }
            MediaPlayer.Event.Playing -> {
                playBtn.text = "⏸"
                miniPlay.text = "⏸"
                if (pendingSeek > 0L) {
                    player.setTime(pendingSeek)
                    pendingSeek = 0L
                }
                player.setVolume(volPct)
                if (current?.audio == true) startBgService()
            }
            MediaPlayer.Event.Paused -> {
                playBtn.text = "▶"
                miniPlay.text = "▶"
                stopBgService()
            }
            MediaPlayer.Event.Stopped -> {
                playBtn.text = "▶"
                miniPlay.text = "▶"
            }
            MediaPlayer.Event.EndReached -> handler.post { onEnded() }
            MediaPlayer.Event.EncounteredError -> {
                Toast.makeText(this, "Ye file play nahi ho payi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startQueue(items: List<Item>, index: Int) {
        queue = items
        playAt(index)
    }

    private fun playAt(i: Int) {
        if (i < 0 || i >= queue.size) return
        saveProgress()
        qIndex = i
        val item = queue[i]
        val local = item.uri.scheme == "content" || item.uri.scheme == "file"
        pendingSeek = if (local) prefs.getLong("pos_" + item.uri.toString(), 0L) else 0L
        if (!openMedia(item.uri)) return
        current = item
        pushRecent(item)
        titleText.text = item.title
        audioArt.visibility = if (item.audio) View.VISIBLE else View.GONE
        player.setRate(1f)
        speedBtn.text = "1x"
        applyScale(scaleIdx, false)
        showPlayer()
        updateMini()
    }

    private fun openMedia(uri: Uri): Boolean {
        return try {
            pfd?.close()
            pfd = null
            val media: Media
            if (uri.scheme == "content" || uri.scheme == "file") {
                pfd = contentResolver.openFileDescriptor(uri, "r")
                media = Media(libVLC, pfd!!.fileDescriptor)
            } else {
                media = Media(libVLC, uri)
            }
            player.setMedia(media)
            media.release()
            player.play()
            true
        } catch (e: Exception) {
            Toast.makeText(this, "File nahi khul payi", Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun onEnded() {
        current?.let { prefs.edit().remove("pos_" + it.uri.toString()).apply() }
        when {
            repeatMode == 2 -> playAt(qIndex)
            shuffle && queue.size > 1 -> playAt(randomIndex())
            qIndex + 1 < queue.size -> playAt(qIndex + 1)
            repeatMode == 1 && queue.isNotEmpty() -> playAt(0)
            else -> {
                playBtn.text = "▶"
                miniPlay.text = "▶"
                stopBgService()
                showControls(true)
            }
        }
    }

    private fun randomIndex(): Int {
        var r = (0 until queue.size).random()
        if (queue.size > 1) {
            while (r == qIndex) r = (0 until queue.size).random()
        }
        return r
    }

    private fun next() {
        if (queue.isEmpty()) return
        if (shuffle && queue.size > 1) playAt(randomIndex())
        else if (qIndex + 1 < queue.size) playAt(qIndex + 1)
        else if (repeatMode == 1) playAt(0)
        else showOsd("Last item")
    }

    private fun prev() {
        if (queue.isEmpty()) return
        if (player.getTime() > 3000L) player.setTime(0L)
        else if (qIndex > 0) playAt(qIndex - 1)
        else if (repeatMode == 1) playAt(queue.size - 1)
        else player.setTime(0L)
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun seekBy(ms: Long) {
        var t = player.getTime() + ms
        if (t < 0L) t = 0L
        val len = player.getLength()
        if (len > 0L && t > len) t = len
        player.setTime(t)
        showOsd((if (ms > 0) "⏩ +" else "⏪ -") + abs(ms / 1000) + "s")
    }

    private fun saveProgress() {
        val c = current ?: return
        if (c.uri.scheme != "content" && c.uri.scheme != "file") return
        val len = player.getLength()
        if (len <= 0L) return
        val t = player.getTime()
        val e = prefs.edit()
        val key = "pos_" + c.uri.toString()
        if (t > 5000L && t < len - 5000L) e.putLong(key, t) else e.remove(key)
        e.apply()
    }

    private fun applyScale(i: Int, announce: Boolean = true) {
        when (i) {
            0 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT)
            1 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
            2 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL)
            3 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_16_9)
            4 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_4_3)
            else -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_ORIGINAL)
        }
        if (announce) showOsd("⤢ " + scaleNames[i])
    }

    // =====================================================================
    // Dialogs and extras
    // =====================================================================

    private fun choose(title: String, options: Array<String>, checked: Int, onPick: (Int) -> Unit) {
        val b = AlertDialog.Builder(this).setTitle(title)
        if (checked >= 0) {
            b.setSingleChoiceItems(options, checked) { d, i ->
                onPick(i)
                d.dismiss()
            }
        } else {
            b.setItems(options) { _, i -> onPick(i) }
        }
        b.show()
    }

    private fun pickTrack(
        title: String,
        tracks: Array<MediaPlayer.TrackDescription>?,
        current: Int,
        onPick: (Int) -> Unit
    ) {
        if (tracks == null || tracks.isEmpty()) {
            Toast.makeText(this, "Koi track nahi mila", Toast.LENGTH_SHORT).show()
            return
        }
        val names = Array(tracks.size) { tracks[it].name ?: "Track" }
        val checked = tracks.indexOfFirst { it.id == current }
        choose(title, names, if (checked < 0) 0 else checked) { onPick(tracks[it].id) }
    }

    private fun speedDialog() {
        val names = Array(speeds.size) { speeds[it].toString().removeSuffix(".0") + "x" }
        val cur = speeds.indexOfFirst { it == player.getRate() }
        choose("Speed", names, if (cur < 0) 3 else cur) {
            player.setRate(speeds[it])
            speedBtn.text = names[it]
        }
    }

    private fun sleepDialog() {
        val opts = arrayOf("Off", "15 min", "30 min", "45 min", "60 min", "90 min")
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        choose("Sleep timer", opts, -1) { i ->
            sleepRunnable?.let { handler.removeCallbacks(it) }
            sleepRunnable = null
            if (mins[i] > 0) {
                val r = Runnable {
                    player.pause()
                    showOsd("🌙 Sleep timer: paused")
                }
                sleepRunnable = r
                handler.postDelayed(r, mins[i] * 60000L)
                showOsd("🌙 " + mins[i] + " min baad band")
            } else {
                showOsd("Sleep timer off")
            }
        }
    }

    private fun moreDialog() {
        val opts = arrayOf(
            "📝 Subtitle file load karo",
            "⏱ Subtitle delay",
            "🔈 Audio delay",
            "🎚 Equalizer",
            "🔄 Rotate screen"
        )
        choose("More", opts, -1) { i ->
            when (i) {
                0 -> pickSubtitle()
                1 -> delayDialog(false)
                2 -> delayDialog(true)
                3 -> equalizerDialog()
                4 -> cycleOrientation()
            }
        }
    }

    private fun delayDialog(audio: Boolean) {
        val base = if (audio) player.getAudioDelay() else player.getSpuDelay()
        val label = (if (audio) "Audio" else "Subtitle") + " delay: " + (base / 1000) + " ms"
        choose(label, arrayOf("-100 ms", "+100 ms", "Reset"), -1) { i ->
            val nv = when (i) {
                0 -> base - 100000L
                1 -> base + 100000L
                else -> 0L
            }
            if (audio) player.setAudioDelay(nv) else player.setSpuDelay(nv)
            delayDialog(audio)
        }
    }

    private fun equalizerDialog() {
        val n = MediaPlayer.Equalizer.getPresetCount()
        val names = Array(n + 1) { if (it == 0) "Off" else MediaPlayer.Equalizer.getPresetName(it - 1) }
        choose("Equalizer", names, -1) { i ->
            if (i == 0) player.setEqualizer(null)
            else player.setEqualizer(MediaPlayer.Equalizer.createFromPreset(i - 1))
            showOsd("🎚 " + names[i])
        }
    }

    private fun cycleOrientation() {
        orientMode = (orientMode + 1) % 3
        requestedOrientation = when (orientMode) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        showOsd(arrayOf("Auto rotate", "Landscape", "Portrait")[orientMode])
    }

    // =====================================================================
    // File pickers
    // =====================================================================

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
        startActivityForResult(i, REQ_OPEN)
    }

    private fun pickSubtitle() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, REQ_SUB)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQ_OPEN) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            handleViewUri(uri)
        } else if (requestCode == REQ_SUB) {
            addSubtitle(uri)
        }
    }

    private fun handleViewUri(uri: Uri) {
        val audio = (contentResolver.getType(uri) ?: "").startsWith("audio")
        val name = queryName(uri)
        startQueue(listOf(Item(uri, name.substringBeforeLast('.'), "File", audio, 0L, 0L, 0L)), 0)
    }

    private fun queryName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (n != null) return n
                }
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "Video"
    }

    private fun addSubtitle(uri: Uri) {
        try {
            val ext = queryName(uri).substringAfterLast('.', "srt")
            val f = File(cacheDir, "sub_" + System.currentTimeMillis() + "." + ext)
            contentResolver.openInputStream(uri)?.use { inp ->
                f.outputStream().use { out -> inp.copyTo(out) }
            }
            player.addSlave(Media.Slave.Type.Subtitle, Uri.fromFile(f), true)
            showOsd("📝 Subtitle load ho gaya")
        } catch (e: Exception) {
            Toast.makeText(this, "Subtitle load nahi hui", Toast.LENGTH_SHORT).show()
        }
    }

    // =====================================================================
    // Background service + helpers
    // =====================================================================

    private fun startBgService() {
        try {
            val i = Intent(this, PlayService::class.java)
            i.putExtra("title", current?.title ?: "VPlayer")
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
        }
    }

    private fun stopBgService() {
        try {
            stopService(Intent(this, PlayService::class.java))
        } catch (e: Exception) {
        }
    }

    private fun fmt(ms: Long): String {
        val s = if (ms < 0L) 0L else ms / 1000L
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
        else String.format("%02d:%02d", m, sec)
    }

    private fun humanSize(b: Long): String {
        return when {
            b >= 1000000000L -> String.format("%.1f GB", b / 1e9)
            b >= 1000000L -> String.format("%.0f MB", b / 1e6)
            else -> String.format("%.0f KB", b / 1e3)
        }
    }
}
