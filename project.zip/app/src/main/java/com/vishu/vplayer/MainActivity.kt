package com.vishu.vplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ContentUris
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

data class Item(
    val uri: Uri,
    val title: String,
    val sub: String,
    val audio: Boolean,
    val added: Long,
    val size: Long,
    val dur: Long,
    val bucket: String = ""
)

class Folder(
    val name: String,
    val count: Int,
    val covers: List<Item>,
    val latest: Long,
    val size: Long
)

class MenuRow(
    val icon: Int,
    val label: String,
    val iconText: String? = null,
    val onClick: () -> Unit
)

class MainActivity : Activity() {

    companion object {
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        const val REQ_OPEN = 1
        const val REQ_SUB = 2
        const val REQ_PERM = 3
    }

    // VLC ke screenshot se liye gaye colors
    private val orange = Color.parseColor("#EE8331")     // selected tab, FAB, seekbar
    private val bg = Color.parseColor("#131313")         // page / toolbar background
    private val surface = Color.parseColor("#2A2A2A")    // bottom nav, mini player
    private val iconGray = Color.parseColor("#C4C4C4")   // toolbar icons + title, "33 videos"
    private val navGray = Color.parseColor("#A5A5A5")    // bottom nav (unselected)
    private val tabWhite = Color.parseColor("#E7E7E7")   // top tab (unselected)
    private val divider = Color.parseColor("#424242")    // nav ke upar patli line

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private var pfd: ParcelFileDescriptor? = null
    private var attached = false

    // ---------- library views ----------
    private lateinit var root: FrameLayout
    private lateinit var library: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    private lateinit var gridView: GridView
    private lateinit var navItems: Array<LinearLayout>
    private lateinit var toolbarLogo: ImageView
    private lateinit var toolbarTitle: TextView
    private lateinit var searchBar: LinearLayout
    private lateinit var topTabs: LinearLayout
    private lateinit var fab: ImageButton
    private lateinit var pageBrowse: LinearLayout
    private lateinit var pageMore: LinearLayout
    private lateinit var pagePlaylists: TextView
    private lateinit var miniBar: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: ImageButton

    // ---------- player views ----------
    private lateinit var playerScreen: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var audioArt: ImageView
    private lateinit var touchLayer: View
    private lateinit var topBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var controls: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var lengthText: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var osd: TextView
    private lateinit var unlockBtn: ImageButton

    // ---------- state ----------
    private var tab = 0
    private var sortMode = 0
    private var allItems: List<Item> = emptyList()
    private var shownItems: List<Item> = emptyList()
    private var currentFolder: String? = null
    private var videoSubTab = 0   // 0 = VIDEOS, 1 = PLAYLISTS
    private var gridFolders: List<Folder> = emptyList()
    private var gridVideos: List<Item> = emptyList()
    private var gridIsFolders = true
    private var queue: List<Item> = emptyList()
    private var qIndex = -1
    private var current: Item? = null
    private var shuffle = false
    private var repeatMode = 0
    private var locked = false
    private var pendingSeek = 0L
    private var lastSave = 0L
    private var length = 0L
    private var userSeeking = false
    private var sleepRunnable: Runnable? = null
    private var orientMode = 0
    private var orientListener: OrientationEventListener? = null
    private var scaleIdx = 0
    private var volPct = 100
    private var pendingView: Uri? = null

    // gesture state
    private var gestureMode = 0
    private var startTime = 0L
    private var startBright = 0.5f
    private var startVol = 100
    private var seekTarget = 0L

    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
    private val scaleNames = arrayOf("Best fit", "Fit screen", "Fill", "16:9", "4:3", "Original")
    private val sortNames = arrayOf("Newest", "Name", "Size")

    private val hideOsd = Runnable { osd.visibility = View.GONE }
    private val hideRunnable = Runnable {
        if (player.isPlaying && current?.audio != true && !locked) showControls(false)
    }

    private lateinit var gd: GestureDetector

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shownItems.size
        override fun getItem(position: Int): Any = shownItems[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: makeRow()
            val item = shownItems[position]
            (row.getChildAt(0) as ImageView).setImageResource(
                if (item.audio) R.drawable.ic_music_file else R.drawable.ic_video
            )
            val col = row.getChildAt(1) as LinearLayout
            (col.getChildAt(0) as TextView).text = item.title
            (col.getChildAt(1) as TextView).text = item.sub
            return row
        }
    }

    // ---------- VLC jaisa card grid (folder / video) ----------

    private val thumbCache = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val thumbPool = Executors.newFixedThreadPool(3)

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = if (gridIsFolders) gridFolders.size else gridVideos.size
        override fun getItem(position: Int): Any =
            if (gridIsFolders) gridFolders[position] else gridVideos[position]

        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val card = (convertView as? LinearLayout) ?: makeCard()
            val box = card.getChildAt(0) as FrameLayout
            val lp = box.layoutParams
            lp.height = thumbHeight()
            box.layoutParams = lp
            val placeholder = box.getChildAt(0) as ImageView
            val mosaic = box.getChildAt(1) as LinearLayout
            val rowTop = mosaic.getChildAt(0) as LinearLayout
            val rowBottom = mosaic.getChildAt(1) as LinearLayout
            val tiles = arrayOf(
                rowTop.getChildAt(0) as ImageView, rowTop.getChildAt(1) as ImageView,
                rowBottom.getChildAt(0) as ImageView, rowBottom.getChildAt(1) as ImageView
            )
            val badge = box.getChildAt(2) as TextView
            val more = box.getChildAt(3) as ImageButton
            val title = card.getChildAt(1) as TextView
            val sub = card.getChildAt(2) as TextView

            if (gridIsFolders) {
                val f = gridFolders[position]
                placeholder.setImageResource(R.drawable.ic_folder_open)
                title.text = f.name
                sub.text = if (f.count == 1) "1 video" else f.count.toString() + " videos"
                badge.visibility = View.GONE
                // VLC jaisa mosaic: 1 = pura, 2 = do baraabar, 3 = upar 2 + neeche 1 chauda, 4 = 2x2
                val n = f.covers.size
                tiles[0].visibility = View.VISIBLE
                tiles[1].visibility = if (n >= 2) View.VISIBLE else View.GONE
                rowBottom.visibility = if (n >= 3) View.VISIBLE else View.GONE
                tiles[2].visibility = View.VISIBLE
                tiles[3].visibility = if (n >= 4) View.VISIBLE else View.GONE
                for (k in 0 until 4) {
                    if (k < n) loadThumb(tiles[k], f.covers[k].uri)
                    else {
                        tiles[k].tag = null
                        tiles[k].setImageDrawable(null)
                    }
                }
                more.setOnClickListener { showFolderMenu(f) }
            } else {
                val v = gridVideos[position]
                placeholder.setImageResource(R.drawable.ic_nav_video)
                title.text = v.title
                sub.text = humanSize(v.size)
                badge.text = fmt(v.dur)
                badge.visibility = View.VISIBLE
                tiles[0].visibility = View.VISIBLE
                tiles[1].visibility = View.GONE
                rowBottom.visibility = View.GONE
                loadThumb(tiles[0], v.uri)
                more.setOnClickListener { showVideoMenu(v, position) }
            }
            return card
        }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("vplayer", MODE_PRIVATE)
        libVLC = LibVLC(
            this,
            arrayListOf("--no-drop-late-frames", "--no-skip-frames", "--network-caching=1500")
        )
        player = MediaPlayer(libVLC)

        window.statusBarColor = bg
        window.navigationBarColor = surface

        root = FrameLayout(this)
        root.setBackgroundColor(bg)
        buildLibrary()
        buildPlayer()
        root.addView(library, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(playerScreen, FrameLayout.LayoutParams(MATCH, MATCH))
        playerScreen.visibility = View.GONE
        setContentView(root)

        player.setEventListener(MediaPlayer.EventListener { e ->
            runOnUiThread { onPlayerEvent(e) }
        })

        refreshTabs()
        ensurePermission()

        if (intent?.action == Intent.ACTION_VIEW) pendingView = intent.data
    }

    override fun onStart() {
        super.onStart()
        if (playerScreen.visibility == View.VISIBLE && !attached) {
            player.attachViews(videoLayout, null, true, false)
            attached = true
        }
        if (playerScreen.visibility == View.VISIBLE && orientMode == 0) startAutoRotate()
        pendingView?.let {
            handleViewUri(it)
            pendingView = null
        }
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        orientListener?.disable()
        if (current?.audio != true) player.pause()
        if (attached) {
            player.detachViews()
            attached = false
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_VIEW) intent.data?.let { handleViewUri(it) }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (playerScreen.visibility == View.VISIBLE && player.isPlaying && current?.audio != true) {
            enterPip()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (playerScreen.visibility == View.VISIBLE) leavePlayer()
        else if (tab == 5 || (tab == 0 && currentFolder != null)) toolbarBack()
        else if (searchBar.visibility == View.VISIBLE) toggleSearch()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        saveProgress()
        orientListener?.disable()
        handler.removeCallbacksAndMessages(null)
        stopBgService()
        try {
            player.stop()
            player.release()
            libVLC.release()
            pfd?.close()
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // Permissions and library
    // =====================================================================

    private fun needPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun ensurePermission() {
        val need = needPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) loadLibrary() else requestPermissions(need.toTypedArray(), REQ_PERM)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        loadLibrary()
    }

    private fun loadLibrary() {
        val t = tab
        Thread {
            val list: List<Item> = when (t) {
                0 -> queryMedia(true)
                1 -> queryMedia(false)
                5 -> loadRecent()
                else -> emptyList()
            }
            runOnUiThread {
                allItems = list
                applyFilter()
            }
        }.start()
    }

    private fun queryMedia(video: Boolean): List<Item> {
        val out = ArrayList<Item>()
        try {
            val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val durCol = if (video) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION
            val proj = if (video) arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                durCol,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME
            ) else arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                durCol,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_ADDED
            )
            contentResolver.query(base, proj, null, null, null)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(durCol)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val iBucket = if (video) c.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME) else -1
                while (c.moveToNext()) {
                    val dur = c.getLong(iDur)
                    if (!video && dur < 20000L) continue
                    val name = c.getString(iName) ?: "?"
                    val size = c.getLong(iSize)
                    out.add(
                        Item(
                            ContentUris.withAppendedId(base, c.getLong(iId)),
                            name.substringBeforeLast('.'),
                            fmt(dur) + "  •  " + humanSize(size),
                            !video,
                            c.getLong(iAdded),
                            size,
                            dur,
                            if (iBucket >= 0) (c.getString(iBucket) ?: "") else ""
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun folderKey(item: Item): String = if (item.bucket.isEmpty()) "Other" else item.bucket

    private fun hideAllPages() {
        gridView.visibility = View.GONE
        listView.visibility = View.GONE
        emptyText.visibility = View.GONE
        pageBrowse.visibility = View.GONE
        pageMore.visibility = View.GONE
        pagePlaylists.visibility = View.GONE
    }

    // tab: 0 Video, 1 Audio, 2 Browse, 3 Playlists, 4 More, 5 History (More ke andar)
    private fun applyFilter() {
        val q = searchBox.text.toString().trim().lowercase()
        updateToolbar()
        hideAllPages()
        when {
            tab == 0 && videoSubTab == 1 -> pagePlaylists.visibility = View.VISIBLE
            tab == 0 -> {
                val fname = currentFolder
                var count: Int
                if (fname == null) {
                    val groups = allItems.groupBy { folderKey(it) }
                    var fl: List<Folder> = groups.map { (name, list) ->
                        val newest = list.sortedByDescending { it.added }
                        Folder(name, list.size, newest.take(4), newest[0].added, list.sumOf { it.size })
                    }
                    if (q.isNotEmpty()) fl = fl.filter { it.name.lowercase().contains(q) }
                    fl = when (sortMode) {
                        1 -> fl.sortedBy { it.name.lowercase() }
                        2 -> fl.sortedByDescending { it.size }
                        else -> fl.sortedByDescending { it.latest }
                    }
                    gridFolders = fl
                    gridIsFolders = true
                    count = fl.size
                } else {
                    var vl: List<Item> = allItems.filter { folderKey(it) == fname }
                    if (q.isNotEmpty()) vl = vl.filter { it.title.lowercase().contains(q) }
                    vl = when (sortMode) {
                        1 -> vl.sortedBy { it.title.lowercase() }
                        2 -> vl.sortedByDescending { it.size }
                        else -> vl.sortedByDescending { it.added }
                    }
                    gridVideos = vl
                    gridIsFolders = false
                    count = vl.size
                }
                gridAdapter.notifyDataSetChanged()
                gridView.visibility = View.VISIBLE
                emptyText.visibility = if (count == 0) View.VISIBLE else View.GONE
            }
            tab == 1 || tab == 5 -> {
                var l: List<Item> = if (q.isEmpty()) allItems else allItems.filter { it.title.lowercase().contains(q) }
                if (tab == 1) {
                    l = when (sortMode) {
                        1 -> l.sortedBy { it.title.lowercase() }
                        2 -> l.sortedByDescending { it.size }
                        else -> l.sortedByDescending { it.added }
                    }
                }
                shownItems = l
                adapter.notifyDataSetChanged()
                listView.visibility = View.VISIBLE
                emptyText.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
            }
            tab == 2 -> pageBrowse.visibility = View.VISIBLE
            tab == 3 -> pagePlaylists.visibility = View.VISIBLE
            else -> pageMore.visibility = View.VISIBLE
        }
        topTabs.visibility = if (tab == 0 && currentFolder == null) View.VISIBLE else View.GONE
        refreshTopTabs()
        fab.visibility = if ((tab == 0 && videoSubTab == 0) || tab == 1) View.VISIBLE else View.GONE
    }

    // toolbar: normal me [logo] eve ,  folder / history ke andar [back] naam
    private fun updateToolbar() {
        val f = currentFolder
        if (tab == 0 && f != null) {
            setToolbarBack(f)
        } else if (tab == 5) {
            setToolbarBack("History")
        } else {
            toolbarLogo.setImageResource(R.drawable.logo_crop)
            toolbarLogo.clearColorFilter()
            toolbarLogo.setPadding(0, 0, 0, 0)
            toolbarTitle.text = Ui.APP_NAME
        }
    }

    private fun setToolbarBack(title: String) {
        toolbarLogo.setImageResource(R.drawable.ic_back)
        toolbarLogo.setColorFilter(iconGray)
        toolbarLogo.setPadding(dp(2), dp(3), dp(2), dp(3))
        toolbarTitle.text = title
    }

    private fun toolbarBack() {
        if (tab == 5) {
            tab = 4
            refreshTabs()
            applyFilter()
        } else if (tab == 0 && currentFolder != null) {
            exitFolder()
        }
    }

    private fun exitFolder() {
        currentFolder = null
        applyFilter()
        gridView.setSelection(0)
    }

    private fun toggleSearch() {
        val show = searchBar.visibility != View.VISIBLE
        searchBar.visibility = if (show) View.VISIBLE else View.GONE
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (show) {
            searchBox.requestFocus()
            imm.showSoftInput(searchBox, 0)
        } else {
            searchBox.setText("")
            imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        }
    }

    private fun onGridClick(pos: Int) {
        if (gridIsFolders) {
            currentFolder = gridFolders[pos].name
            applyFilter()
            gridView.setSelection(0)
        } else {
            startQueue(gridVideos, pos)
        }
    }

    // "Play all" / FAB ke liye: abhi screen pe jo dikh raha hai wahi list
    private fun currentPlayables(): List<Item> =
        if (tab == 0) (if (currentFolder == null) allItems else gridVideos) else shownItems

    private fun playAllCurrent() {
        val list = currentPlayables()
        if (list.isEmpty()) Toast.makeText(this, "No files found", Toast.LENGTH_SHORT).show()
        else startQueue(list, 0)
    }

    private fun resumeLast() {
        val r = loadRecent()
        if (r.isEmpty()) Toast.makeText(this, "History is empty", Toast.LENGTH_SHORT).show()
        else startQueue(r, 0)
    }

    // bottom nav: selected = orange + bold, baaki grey
    private fun refreshTabs() {
        val sel = if (tab == 5) 4 else tab
        for (i in navItems.indices) {
            val on = i == sel
            val c = if (on) orange else navGray
            (navItems[i].getChildAt(0) as ImageView).setColorFilter(c)
            val label = navItems[i].getChildAt(1) as TextView
            label.setTextColor(c)
            label.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    // top tabs (VIDEOS | PLAYLISTS): selected = orange text + orange underline
    private fun refreshTopTabs() {
        for (i in 0 until topTabs.childCount) {
            val f = topTabs.getChildAt(i) as FrameLayout
            val on = i == videoSubTab
            (f.getChildAt(0) as TextView).setTextColor(if (on) orange else tabWhite)
            f.getChildAt(1).visibility = if (on) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun loadRecent(): List<Item> {
        val raw = prefs.getString("recent", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("\t")
            if (p.size < 3) null
            else Item(Uri.parse(p[0]), p[1], if (p[2] == "1") "Music" else "Video", p[2] == "1", 0L, 0L, 0L)
        }
    }

    private fun pushRecent(item: Item) {
        val key = item.uri.toString()
        val line = key + "\t" + item.title.replace("\t", " ").replace("\n", " ") +
                "\t" + (if (item.audio) "1" else "0")
        val l = ArrayList<String>()
        l.add(line)
        (prefs.getString("recent", "") ?: "").split("\n")
            .filter { it.isNotBlank() && !it.startsWith(key + "\t") }
            .forEach { l.add(it) }
        prefs.edit().putString("recent", l.take(30).joinToString("\n")).apply()
    }

    // =====================================================================
    // UI: library
    // =====================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun makeRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        val ic = ImageView(this)
        ic.setColorFilter(orange)
        r.addView(ic, LinearLayout.LayoutParams(dp(Ui.ROW_ICON), dp(Ui.ROW_ICON)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, 0, 0)
        val a = TextView(this)
        a.setTextColor(Color.WHITE)
        a.textSize = 16f
        a.maxLines = 1
        a.ellipsize = TextUtils.TruncateAt.END
        val b = TextView(this)
        b.setTextColor(Color.GRAY)
        b.textSize = 12f
        b.maxLines = 1
        col.addView(a)
        col.addView(b)
        r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    // ---------- icon helpers ----------

    private fun iconDrawable(res: Int, sizeDp: Int, color: Int): Drawable {
        val d = resources.getDrawable(res, theme).mutate()
        d.setBounds(0, 0, dp(sizeDp), dp(sizeDp))
        d.setTint(color)
        return d
    }

    private fun iconBtn(res: Int, btnDp: Int, iconDp: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setBackgroundColor(Color.TRANSPARENT)
        val pad = dp((btnDp - iconDp) / 2)
        b.setPadding(pad, pad, pad, pad)
        b.contentDescription = desc
        b.setOnClickListener { onClick() }
        return b
    }

    private fun setPlayIcons(playing: Boolean) {
        val r = if (playing) R.drawable.ic_pause else R.drawable.ic_play
        playBtn.setImageResource(r)
        miniPlay.setImageResource(r)
    }

    private fun iconMenu(title: String, rows: List<MenuRow>) {
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8), dp(4), dp(8), dp(4))
        val sv = ScrollView(this)
        sv.addView(list, ViewGroup.LayoutParams(MATCH, WRAP))
        val dlg = AlertDialog.Builder(this).setTitle(title).setView(sv).create()
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(8), 0, dp(8), 0)
            row.isClickable = true
            row.setBackgroundResource(tv.resourceId)
            if (r.icon != 0) {
                val iv = ImageView(this)
                iv.setImageResource(r.icon)
                iv.setColorFilter(Color.WHITE)
                row.addView(iv, LinearLayout.LayoutParams(dp(Ui.MENU_ICON), dp(Ui.MENU_ICON)))
            } else {
                val t = TextView(this)
                t.text = r.iconText ?: ""
                t.setTextColor(Color.WHITE)
                t.textSize = 13f
                t.setTypeface(null, Typeface.BOLD)
                t.gravity = Gravity.CENTER
                row.addView(t, LinearLayout.LayoutParams(dp(Ui.MENU_ICON), dp(Ui.MENU_ICON)))
            }
            val label = TextView(this)
            label.text = r.label
            label.setTextColor(Color.WHITE)
            label.textSize = 16f
            label.setPadding(dp(16), 0, 0, 0)
            row.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.setOnClickListener {
                dlg.dismiss()
                r.onClick()
            }
            list.addView(row, LinearLayout.LayoutParams(MATCH, dp(Ui.MENU_ROW_H)))
        }
        dlg.show()
    }

    private fun flatBtn(label: String): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setTextColor(Color.WHITE)
        return b
    }

    private fun gridCols(): Int =
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
            Ui.COLS_LANDSCAPE else Ui.COLS_PORTRAIT

    private fun thumbHeight(): Int {
        val cols = gridCols()
        val total = resources.displayMetrics.widthPixels
        val w = (total - 2 * dp(Ui.GRID_PAD_H) - (cols - 1) * dp(Ui.GRID_GAP)) / cols
        return w * Ui.THUMB_H / Ui.THUMB_W
    }

    private fun makeTile(): ImageView {
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        return iv
    }

    private fun makeTileRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(makeTile(), LinearLayout.LayoutParams(0, MATCH, 1f))
        row.addView(makeTile(), LinearLayout.LayoutParams(0, MATCH, 1f))
        return row
    }

    // Ek card = thumbnail box (mosaic + duration badge + 3-dot) + naam + "N videos"
    private fun makeCard(): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL

        val box = FrameLayout(this)
        val shape = GradientDrawable()
        shape.setColor(Color.BLACK)
        shape.cornerRadius = dp(Ui.THUMB_RADIUS).toFloat()
        box.background = shape
        box.clipToOutline = true

        // child 0: placeholder icon
        val ph = ImageView(this)
        ph.setColorFilter(Color.DKGRAY)
        box.addView(ph, FrameLayout.LayoutParams(dp(Ui.PLACEHOLDER_ICON), dp(Ui.PLACEHOLDER_ICON), Gravity.CENTER))

        // child 1: mosaic (2 rows x 2 tiles)
        val mosaic = LinearLayout(this)
        mosaic.orientation = LinearLayout.VERTICAL
        mosaic.addView(makeTileRow(), LinearLayout.LayoutParams(MATCH, 0, 1f))
        mosaic.addView(makeTileRow(), LinearLayout.LayoutParams(MATCH, 0, 1f))
        box.addView(mosaic, FrameLayout.LayoutParams(MATCH, MATCH))

        // child 2: duration badge
        val badge = TextView(this)
        badge.setTextColor(Color.WHITE)
        badge.textSize = Ui.BADGE_SP
        badge.setPadding(dp(6), dp(2), dp(6), dp(2))
        badge.setBackgroundColor(Color.argb(180, 0, 0, 0))
        badge.visibility = View.GONE
        val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
        blp.setMargins(0, 0, dp(6), dp(6))
        box.addView(badge, blp)

        // child 3: vertical 3-dot (thumbnail ke upar right)
        val more = ImageButton(this)
        more.setImageResource(R.drawable.ic_card_more)
        more.setColorFilter(Color.WHITE)
        more.setBackgroundColor(Color.TRANSPARENT)
        more.scaleType = ImageView.ScaleType.FIT_CENTER
        more.isFocusable = false
        more.setPadding(dp(4), dp(4), dp(4), dp(4))
        val mlp = FrameLayout.LayoutParams(dp(Ui.CARD_MORE_BTN), dp(Ui.CARD_MORE_BTN), Gravity.TOP or Gravity.END)
        mlp.setMargins(0, dp(Ui.CARD_MORE_TOP), 0, 0)
        box.addView(more, mlp)

        val title = TextView(this)
        title.setTextColor(Color.WHITE)
        title.textSize = Ui.CARD_TITLE_SP
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        title.setPadding(0, dp(Ui.CARD_TITLE_GAP), 0, 0)

        val sub = TextView(this)
        sub.setTextColor(iconGray)
        sub.textSize = Ui.CARD_SUB_SP
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END

        card.addView(box, LinearLayout.LayoutParams(MATCH, dp(100)))
        card.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(sub, LinearLayout.LayoutParams(MATCH, WRAP))
        return card
    }

    private fun showFolderMenu(f: Folder) {
        val list = allItems.filter { folderKey(it) == f.name }.sortedBy { it.title.lowercase() }
        iconMenu(f.name, listOf(
            MenuRow(R.drawable.ic_play, "Play all") { startQueue(list, 0) },
            MenuRow(R.drawable.ic_shuffle, "Play shuffled") {
                shuffle = true
                startQueue(list, (0 until list.size).random())
            }
        ))
    }

    private fun showVideoMenu(v: Item, pos: Int) {
        iconMenu(v.title, listOf(
            MenuRow(R.drawable.ic_play, "Play") { startQueue(gridVideos, pos) },
            MenuRow(0, "Info", "i") {
                AlertDialog.Builder(this)
                    .setTitle(v.title)
                    .setMessage("Duration: " + fmt(v.dur) + "\nSize: " + humanSize(v.size) + "\nFolder: " + folderKey(v))
                    .setPositiveButton("OK", null)
                    .show()
            }
        ))
    }

    private fun loadThumb(iv: ImageView, uri: Uri) {
        val key = uri.toString()
        iv.tag = key
        val hit = thumbCache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        thumbPool.execute {
            val bmp = makeThumb(uri)
            if (bmp != null) {
                thumbCache.put(key, bmp)
                runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bmp) }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun makeThumb(uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                contentResolver.loadThumbnail(uri, Size(400, 250), null)
            } else {
                MediaStore.Video.Thumbnails.getThumbnail(
                    contentResolver, ContentUris.parseId(uri),
                    MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        gridView.numColumns = gridCols()
        gridAdapter.notifyDataSetChanged()
    }

    // ---------- chhote helpers ----------

    private fun tbBtn(res: Int, desc: String, widthDp: Int = Ui.BTN, onClick: () -> Unit): ImageButton {
        val b = iconBtn(res, widthDp, Ui.ICON, desc, onClick)
        b.setColorFilter(iconGray)
        return b
    }

    // VIDEOS / PLAYLISTS jaisa ek top tab (text + neeche orange line)
    private fun makeTopTab(label: String, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val t = TextView(this)
        t.text = label
        t.textSize = Ui.TAB_TEXT_SP
        t.letterSpacing = 0.1f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(Ui.TAB_PAD_H), 0, dp(Ui.TAB_PAD_H), 0)
        f.addView(t, FrameLayout.LayoutParams(WRAP, MATCH))
        val ind = View(this)
        val shape = GradientDrawable()
        shape.setColor(orange)
        val r = dp(3).toFloat()
        shape.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        ind.background = shape
        val ilp = FrameLayout.LayoutParams(MATCH, dp(Ui.TAB_IND_H), Gravity.BOTTOM)
        ilp.setMargins(dp(Ui.TAB_PAD_H), 0, dp(Ui.TAB_PAD_H), 0)
        f.addView(ind, ilp)
        f.setOnClickListener { onClick() }
        return f
    }

    // Browse / More jaise simple pages: icon + naam ki rows
    private fun makePage(rows: List<MenuRow>): LinearLayout {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(0, dp(8), 0, 0)
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(20), 0, dp(20), 0)
            row.isClickable = true
            row.setBackgroundResource(tv.resourceId)
            if (r.icon != 0) {
                val iv = ImageView(this)
                iv.setImageResource(r.icon)
                iv.setColorFilter(iconGray)
                row.addView(iv, LinearLayout.LayoutParams(dp(Ui.ICON), dp(Ui.ICON)))
            } else {
                val t = TextView(this)
                t.text = r.iconText ?: ""
                t.setTextColor(iconGray)
                t.textSize = 13f
                t.setTypeface(null, Typeface.BOLD)
                t.gravity = Gravity.CENTER
                row.addView(t, LinearLayout.LayoutParams(dp(Ui.ICON), dp(Ui.ICON)))
            }
            val label = TextView(this)
            label.text = r.label
            label.setTextColor(Color.WHITE)
            label.textSize = 16f
            label.setPadding(dp(20), 0, 0, 0)
            row.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.setOnClickListener { r.onClick() }
            page.addView(row, LinearLayout.LayoutParams(MATCH, dp(56)))
        }
        return page
    }

    private fun aboutDialog() {
        AlertDialog.Builder(this)
            .setTitle(Ui.APP_NAME)
            .setMessage(
                "Version 1.0\n\n" +
                        "Powered by the VLC media engine (libVLC), licensed under LGPL 2.1.\n" +
                        "https://www.videolan.org/vlc/libvlc.html\n\n" +
                        "VLC is a trademark of VideoLAN. This is an independent app and is " +
                        "not affiliated with or endorsed by VideoLAN."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    // =====================================================================
    // MAIN PAGE build (upar se neeche):
    //   toolbar -> search bar -> top tabs -> content (grid/list/pages + FAB)
    //   -> mini player -> bottom nav
    // =====================================================================

    private fun buildLibrary() {
        library = LinearLayout(this)
        library.orientation = LinearLayout.VERTICAL
        library.setBackgroundColor(bg)

        // ---------- 1. TOOLBAR:  [logo] eve ............ [search] [resume] [3-dot] ----------
        val toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setBackgroundColor(bg)
        toolbar.setPadding(dp(Ui.TOOLBAR_PAD_START), 0, 0, 0)

        toolbarLogo = ImageView(this)
        toolbarLogo.setImageResource(R.drawable.logo_crop)
        toolbarLogo.scaleType = ImageView.ScaleType.FIT_CENTER
        toolbarLogo.setOnClickListener { toolbarBack() }
        toolbar.addView(toolbarLogo, LinearLayout.LayoutParams(dp(Ui.LOGO_W), dp(Ui.LOGO_H)))

        toolbarTitle = TextView(this)
        toolbarTitle.text = Ui.APP_NAME
        toolbarTitle.setTextColor(iconGray)
        toolbarTitle.textSize = Ui.TITLE_SP
        toolbarTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        toolbarTitle.maxLines = 1
        toolbarTitle.ellipsize = TextUtils.TruncateAt.END
        toolbarTitle.setPadding(dp(Ui.TITLE_GAP), 0, 0, 0)
        toolbarTitle.setOnClickListener { toolbarBack() }
        toolbar.addView(toolbarTitle, LinearLayout.LayoutParams(0, WRAP, 1f))

        toolbar.addView(
            tbBtn(R.drawable.ic_tb_search, "Search") { toggleSearch() },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )
        toolbar.addView(
            tbBtn(R.drawable.ic_tb_resume, "Resume") { resumeLast() },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )
        toolbar.addView(
            tbBtn(R.drawable.ic_tb_more, "Menu", Ui.TB_MORE_W) { showLibraryMenu(toolbar) },
            LinearLayout.LayoutParams(dp(Ui.TB_MORE_W), dp(Ui.BTN))
        )
        library.addView(toolbar, LinearLayout.LayoutParams(MATCH, dp(Ui.TOOLBAR_H)))

        // ---------- 2. SEARCH BAR (search icon dabane par khulta hai) ----------
        searchBar = LinearLayout(this)
        searchBar.orientation = LinearLayout.HORIZONTAL
        searchBar.gravity = Gravity.CENTER_VERTICAL
        searchBar.setBackgroundColor(surface)
        searchBar.setPadding(dp(16), 0, dp(16), 0)
        val sIcon = ImageView(this)
        sIcon.setImageResource(R.drawable.ic_tb_search)
        sIcon.setColorFilter(iconGray)
        searchBar.addView(sIcon, LinearLayout.LayoutParams(dp(Ui.SEARCH_ICON), dp(Ui.SEARCH_ICON)))
        searchBox = EditText(this)
        searchBox.hint = "Search"
        searchBox.setHintTextColor(Color.GRAY)
        searchBox.setTextColor(Color.WHITE)
        searchBox.setBackgroundColor(Color.TRANSPARENT)
        searchBox.setSingleLine()
        searchBox.setPadding(dp(10), dp(10), 0, dp(10))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        searchBar.addView(searchBox, LinearLayout.LayoutParams(0, WRAP, 1f))
        searchBar.visibility = View.GONE
        library.addView(searchBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---------- 3. TOP TABS:  VIDEOS | PLAYLISTS ----------
        topTabs = LinearLayout(this)
        topTabs.orientation = LinearLayout.HORIZONTAL
        topTabs.setBackgroundColor(bg)
        topTabs.addView(makeTopTab("VIDEOS") { videoSubTab = 0; applyFilter() }, LinearLayout.LayoutParams(WRAP, MATCH))
        topTabs.addView(makeTopTab("PLAYLISTS") { videoSubTab = 1; applyFilter() }, LinearLayout.LayoutParams(WRAP, MATCH))
        library.addView(topTabs, LinearLayout.LayoutParams(MATCH, dp(Ui.TAB_H)))

        // ---------- 4. CONTENT ----------
        // Swipe left/right yahan par sirf VIDEOS <-> PLAYLISTS tab badalta hai
        // (tab == 0 aur koi folder khula na ho, tabhi kaam karega)
        val content = object : FrameLayout(this) {
            private var downX = 0f
            private var downY = 0f
            private var swiping = false

            override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
                if (tab != 0 || currentFolder != null) return false
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.x; downY = ev.y; swiping = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.x - downX
                        val dy = ev.y - downY
                        if (abs(dx) > dp(20) && abs(dx) > abs(dy) * 1.5f) {
                            swiping = true
                            return true
                        }
                    }
                }
                return false
            }

            override fun onTouchEvent(ev: MotionEvent): Boolean {
                if (!swiping) return false
                when (ev.action) {
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val dx = ev.x - downX
                        if (dx <= -dp(40) && videoSubTab == 0) {
                            videoSubTab = 1; applyFilter()
                        } else if (dx >= dp(40) && videoSubTab == 1) {
                            videoSubTab = 0; applyFilter()
                        }
                        swiping = false
                    }
                }
                return true
            }
        }

        gridView = GridView(this)
        gridView.numColumns = gridCols()
        gridView.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        gridView.horizontalSpacing = dp(Ui.GRID_GAP)
        gridView.verticalSpacing = dp(Ui.GRID_GAP)
        gridView.setPadding(dp(Ui.GRID_PAD_H), dp(Ui.GRID_PAD_TOP), dp(Ui.GRID_PAD_H), dp(Ui.GRID_PAD_BOTTOM))
        gridView.clipToPadding = false
        gridView.selector = ColorDrawable(Color.TRANSPARENT)
        gridView.adapter = gridAdapter
        gridView.setOnItemClickListener { _, _, pos, _ -> onGridClick(pos) }
        content.addView(gridView, FrameLayout.LayoutParams(MATCH, MATCH))

        listView = ListView(this)
        listView.adapter = adapter
        listView.dividerHeight = 0
        listView.visibility = View.GONE
        listView.setOnItemClickListener { _, _, pos, _ -> startQueue(shownItems, pos) }
        content.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))

        pageBrowse = makePage(listOf(
            MenuRow(R.drawable.ic_folder_open, "Open file") { openPicker() },
            MenuRow(R.drawable.ic_network, "Network stream") { streamDialog() }
        ))
        pageBrowse.visibility = View.GONE
        content.addView(pageBrowse, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        pageMore = makePage(listOf(
            MenuRow(R.drawable.ic_history, "History") {
                tab = 5
                refreshTabs()
                loadLibrary()
            },
            MenuRow(0, "Sort by", "A-Z") {
                choose("Sort by", sortNames, sortMode) {
                    sortMode = it
                    applyFilter()
                }
            },
            MenuRow(R.drawable.ic_delete, "Clear history") {
                prefs.edit().remove("recent").apply()
                Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
            },
            MenuRow(0, "About", "i") { aboutDialog() }
        ))
        pageMore.visibility = View.GONE
        content.addView(pageMore, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        pagePlaylists = TextView(this)
        pagePlaylists.text = "No playlists yet"
        pagePlaylists.setTextColor(Color.GRAY)
        pagePlaylists.gravity = Gravity.CENTER
        pagePlaylists.visibility = View.GONE
        content.addView(pagePlaylists, FrameLayout.LayoutParams(MATCH, MATCH))

        emptyText = TextView(this)
        emptyText.text = "Nothing found.\nAllow permission or open a file from the menu above."
        emptyText.setTextColor(Color.GRAY)
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(dp(16), dp(32), dp(16), dp(16))
        emptyText.visibility = View.GONE
        content.addView(emptyText, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))

        // FAB: orange gol play button (sab play karo)
        fab = ImageButton(this)
        fab.setImageResource(R.drawable.ic_fab_play)
        fab.setColorFilter(Color.WHITE)
        fab.scaleType = ImageView.ScaleType.FIT_CENTER
        val fabShape = GradientDrawable()
        fabShape.shape = GradientDrawable.OVAL
        fabShape.setColor(orange)
        fab.background = fabShape
        fab.elevation = dp(6).toFloat()
        fab.setPadding(dp(Ui.FAB_PAD), dp(Ui.FAB_PAD), dp(Ui.FAB_PAD), dp(Ui.FAB_PAD))
        fab.setOnClickListener { playAllCurrent() }
        val flp = FrameLayout.LayoutParams(dp(Ui.FAB), dp(Ui.FAB), Gravity.END or Gravity.BOTTOM)
        flp.setMargins(0, 0, dp(Ui.FAB_MARGIN_END), dp(Ui.FAB_MARGIN_BOTTOM))
        content.addView(fab, flp)

        library.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // ---------- 5. MINI PLAYER (gaana chalte waqt) ----------
        miniBar = LinearLayout(this)
        miniBar.orientation = LinearLayout.HORIZONTAL
        miniBar.gravity = Gravity.CENTER_VERTICAL
        miniBar.setBackgroundColor(surface)
        miniBar.setPadding(dp(16), dp(4), dp(8), dp(4))
        miniTitle = TextView(this)
        miniTitle.setTextColor(Color.WHITE)
        miniTitle.maxLines = 1
        miniTitle.ellipsize = TextUtils.TruncateAt.END
        miniTitle.setOnClickListener { if (current != null) showPlayer() }
        miniBar.addView(miniTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        miniPlay = iconBtn(R.drawable.ic_play, Ui.MINI_BTN, Ui.ICON, "Play/Pause") { togglePlay() }
        miniBar.addView(miniPlay, LinearLayout.LayoutParams(dp(Ui.MINI_BTN), dp(Ui.MINI_BTN)))
        miniBar.visibility = View.GONE
        library.addView(miniBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---------- 6. BOTTOM NAV:  Video | Audio | Browse | Playlists | More ----------
        val line = View(this)
        line.setBackgroundColor(divider)
        library.addView(line, LinearLayout.LayoutParams(MATCH, dp(Ui.DIVIDER)))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(surface)
        val names = arrayOf("Video", "Audio", "Browse", "Playlists", "More")
        val icons = intArrayOf(
            R.drawable.ic_nav_video, R.drawable.ic_nav_audio, R.drawable.ic_nav_browse,
            R.drawable.ic_nav_playlist, R.drawable.ic_nav_more
        )
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        navItems = Array(5) { i ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.isClickable = true
            cell.setBackgroundResource(tv.resourceId)
            val ic = ImageView(this)
            ic.setImageResource(icons[i])
            cell.addView(ic, LinearLayout.LayoutParams(dp(Ui.NAV_ICON), dp(Ui.NAV_ICON)))
            val label = TextView(this)
            label.text = names[i]
            label.textSize = Ui.NAV_TEXT_SP
            label.gravity = Gravity.CENTER
            label.setPadding(0, dp(2), 0, 0)
            cell.addView(label, LinearLayout.LayoutParams(WRAP, WRAP))
            cell.setOnClickListener {
                tab = i
                currentFolder = null
                if (searchBar.visibility == View.VISIBLE) toggleSearch()
                refreshTabs()
                loadLibrary()
            }
            nav.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
            cell
        }
        library.addView(nav, LinearLayout.LayoutParams(MATCH, dp(Ui.NAV_H)))
    }

    private fun showLibraryMenu(anchor: View) {
        iconMenu("Menu", listOf(
            MenuRow(R.drawable.ic_folder_open, "Open file") { openPicker() },
            MenuRow(R.drawable.ic_network, "Network stream") { streamDialog() },
            MenuRow(0, "Sort: " + sortNames[sortMode], "A-Z") {
                sortMode = (sortMode + 1) % sortNames.size
                applyFilter()
            },
            MenuRow(R.drawable.ic_shuffle, "Play all (shuffle)") {
                val list = currentPlayables()
                if (list.isNotEmpty()) {
                    shuffle = true
                    startQueue(list, (0 until list.size).random())
                }
            },
            MenuRow(R.drawable.ic_delete, "Clear history") {
                prefs.edit().remove("recent").apply()
                if (tab == 5) loadLibrary()
            },
            MenuRow(0, "About", "i") { aboutDialog() }
        ))
    }

    private fun streamDialog() {
        val et = EditText(this)
        et.hint = "http://...  rtsp://...  .m3u8"
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setView(et)
            .setPositiveButton("Play") { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) {
                    val uri = Uri.parse(u)
                    startQueue(listOf(Item(uri, uri.lastPathSegment ?: u, "Stream", false, 0L, 0L, 0L)), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =====================================================================
    // UI: player
    // =====================================================================

    private fun ctlBtn(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setPadding(0, dp(8), 0, dp(8))
        b.setOnClickListener {
            onClick()
            scheduleHide()
        }
        parent.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        return b
    }

    private fun buildPlayer() {
        playerScreen = FrameLayout(this)
        playerScreen.setBackgroundColor(Color.BLACK)

        videoLayout = VLCVideoLayout(this)
        playerScreen.addView(videoLayout, FrameLayout.LayoutParams(MATCH, MATCH))

        audioArt = ImageView(this)
        audioArt.setImageResource(R.drawable.ic_music)
        audioArt.setColorFilter(orange)
        audioArt.scaleType = ImageView.ScaleType.FIT_CENTER
        audioArt.visibility = View.GONE
        playerScreen.addView(
            audioArt,
            FrameLayout.LayoutParams(dp(Ui.AUDIO_ART), dp(Ui.AUDIO_ART), Gravity.CENTER)
        )

        touchLayer = View(this)
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = 0
                startTime = player.getTime()
                startBright = currentBrightness()
                startVol = volPct
                seekTarget = startTime
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (!locked) {
                    val show = controls.visibility != View.VISIBLE
                    showControls(show)
                    if (show) scheduleHide()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = touchLayer.width.toFloat()
                if (e.x < w / 3f) seekBy(-10000L)
                else if (e.x > w * 2f / 3f) seekBy(10000L)
                else togglePlay()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null) return true
                val totalX = e2.x - e1.x
                val totalY = e2.y - e1.y
                if (gestureMode == 0) {
                    gestureMode = if (abs(totalX) > abs(totalY)) 1
                    else if (e1.x < touchLayer.width / 2f) 2 else 3
                }
                when (gestureMode) {
                    1 -> {
                        val len = player.getLength()
                        if (len > 0) {
                            var t = startTime + (totalX / touchLayer.width * 120000f).toLong()
                            if (t < 0) t = 0
                            if (t > len) t = len
                            seekTarget = t
                            val diff = (t - startTime) / 1000
                            showOsd(fmt(t) + "  (" + (if (diff >= 0) "+" else "") + diff + "s)")
                        }
                    }
                    2 -> {
                        var b = startBright - totalY / touchLayer.height * 1.5f
                        if (b < 0.02f) b = 0.02f
                        if (b > 1f) b = 1f
                        val lp = window.attributes
                        lp.screenBrightness = b
                        window.attributes = lp
                        showOsd((b * 100).toInt().toString() + "%", R.drawable.ic_brightness)
                    }
                    3 -> {
                        var v = startVol - (totalY / touchLayer.height * 250f).toInt()
                        if (v < 0) v = 0
                        if (v > 200) v = 200
                        volPct = v
                        player.setVolume(v)
                        showOsd("$v%", R.drawable.ic_volume)
                    }
                }
                return true
            }
        })
        touchLayer.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == 1 && !locked) player.setTime(seekTarget)
                gestureMode = 0
            }
            true
        }
        playerScreen.addView(touchLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // top bar: [back] Title
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(Color.argb(Ui.BAR_ALPHA, 0, 0, 0))
        topBar.setPadding(dp(Ui.BAR_PAD_H), dp(4), dp(Ui.BAR_PAD_H), dp(4))
        topBar.addView(
            iconBtn(R.drawable.ic_back, Ui.BTN, Ui.ICON, "Back") { leavePlayer() },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )
        titleText = TextView(this)
        titleText.setTextColor(Color.WHITE)
        titleText.textSize = Ui.TITLE_TEXT_SP
        titleText.maxLines = 1
        titleText.ellipsize = TextUtils.TruncateAt.END
        titleText.setPadding(dp(4), 0, dp(8), 0)
        topBar.addView(titleText, LinearLayout.LayoutParams(0, WRAP, 1f))
        playerScreen.addView(
            topBar,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP)
        )

        // OSD
        osd = TextView(this)
        osd.setTextColor(Color.WHITE)
        osd.textSize = 22f
        osd.gravity = Gravity.CENTER
        osd.setBackgroundColor(Color.argb(170, 0, 0, 0))
        osd.setPadding(dp(20), dp(10), dp(20), dp(10))
        osd.visibility = View.GONE
        playerScreen.addView(
            osd,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER)
        )

        // bottom controls
        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setBackgroundColor(Color.argb(Ui.BAR_ALPHA, 0, 0, 0))
        controls.setPadding(
            dp(Ui.BAR_PAD_H), dp(Ui.BAR_PAD_TOP), dp(Ui.BAR_PAD_H), dp(Ui.BAR_PAD_BOTTOM)
        )

        // time row: current (left) ... total (right)
        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        timeRow.setPadding(dp(8), 0, dp(8), 0)
        timeText = TextView(this)
        timeText.text = "00:00"
        timeText.setTextColor(Color.WHITE)
        timeText.textSize = Ui.TIME_TEXT_SP
        lengthText = TextView(this)
        lengthText.text = "00:00"
        lengthText.setTextColor(Color.WHITE)
        lengthText.textSize = Ui.TIME_TEXT_SP
        lengthText.gravity = Gravity.END
        timeRow.addView(timeText, LinearLayout.LayoutParams(0, WRAP, 1f))
        timeRow.addView(lengthText, LinearLayout.LayoutParams(0, WRAP, 1f))
        controls.addView(timeRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // seekbar
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(orange)
        seek.thumbTintList = ColorStateList.valueOf(orange)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) timeText.text = fmt(p * 1000L)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                userSeeking = false
                player.setTime((s?.progress ?: 0) * 1000L)
            }
        })
        controls.addView(seek, LinearLayout.LayoutParams(MATCH, WRAP))

        // button row: [subtitles][rotate]   (PLAY)   [aspect][more]
        val left = LinearLayout(this)
        left.orientation = LinearLayout.HORIZONTAL
        left.addView(
            ctl(R.drawable.ic_subtitles, Ui.BTN, Ui.ICON, "Subtitles") {
                pickTrack("Subtitles", player.getSpuTracks(), player.getSpuTrack()) {
                    player.setSpuTrack(it)
                }
            },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )
        left.addView(
            ctl(R.drawable.ic_rotate, Ui.BTN, Ui.ICON, "Rotate") { cycleOrientation() },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )

        val right = LinearLayout(this)
        right.orientation = LinearLayout.HORIZONTAL
        right.addView(
            ctl(R.drawable.ic_aspect, Ui.BTN, Ui.ICON, "Aspect ratio") {
                scaleIdx = (scaleIdx + 1) % scaleNames.size
                applyScale(scaleIdx)
            },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )
        right.addView(
            ctl(R.drawable.ic_more, Ui.BTN, Ui.ICON, "More") { moreDialog() },
            LinearLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN))
        )

        playBtn = ctl(R.drawable.ic_play, Ui.PLAY_BTN, Ui.PLAY_ICON, "Play/Pause") { togglePlay() }

        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.CENTER_VERTICAL
        btnRow.addView(left, LinearLayout.LayoutParams(WRAP, WRAP))
        btnRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btnRow.addView(playBtn, LinearLayout.LayoutParams(dp(Ui.PLAY_BTN), dp(Ui.PLAY_BTN)))
        btnRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btnRow.addView(right, LinearLayout.LayoutParams(WRAP, WRAP))
        controls.addView(btnRow, LinearLayout.LayoutParams(MATCH, WRAP))

        playerScreen.addView(
            controls,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        )

        // unlock button (sirf lock ke time dikhta hai)
        unlockBtn = iconBtn(R.drawable.ic_unlock, Ui.BTN, Ui.ICON, "Unlock") { setLocked(false) }
        unlockBtn.setBackgroundColor(Color.argb(Ui.BAR_ALPHA, 0, 0, 0))
        unlockBtn.visibility = View.GONE
        playerScreen.addView(
            unlockBtn,
            FrameLayout.LayoutParams(dp(Ui.BTN), dp(Ui.BTN), Gravity.END or Gravity.CENTER_VERTICAL)
        )
    }

    // bottom bar ke button: click ke baad controls ka auto-hide timer dobara chalta hai
    private fun ctl(res: Int, btnDp: Int, iconDp: Int, desc: String, onClick: () -> Unit): ImageButton {
        return iconBtn(res, btnDp, iconDp, desc) {
            onClick()
            scheduleHide()
        }
    }

    private fun showControls(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        controls.visibility = v
        topBar.visibility = v
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 4000L)
    }

    private fun showOsd(text: String, icon: Int = 0) {
        osd.setCompoundDrawablesRelative(
            if (icon != 0) iconDrawable(icon, Ui.OSD_ICON, Color.WHITE) else null,
            null, null, null
        )
        osd.compoundDrawablePadding = dp(8)
        osd.text = text
        osd.visibility = View.VISIBLE
        handler.removeCallbacks(hideOsd)
        handler.postDelayed(hideOsd, 1000L)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun setLocked(l: Boolean) {
        locked = l
        if (l) {
            showControls(false)
            unlockBtn.visibility = View.VISIBLE
            showOsd("Locked", R.drawable.ic_lock)
        } else {
            unlockBtn.visibility = View.GONE
            showControls(true)
            scheduleHide()
        }
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                ) else 0
    }

    private fun showPlayer() {
        library.visibility = View.GONE
        playerScreen.visibility = View.VISIBLE
        if (!attached) {
            player.attachViews(videoLayout, null, true, false)
            attached = true
        }
        immersive(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (orientMode == 0) startAutoRotate()
        showControls(true)
        scheduleHide()
    }

    private fun leavePlayer() {
        saveProgress()
        if (current?.audio != true) {
            player.stop()
            stopBgService()
            current = null
        }
        playerScreen.visibility = View.GONE
        library.visibility = View.VISIBLE
        immersive(false)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        orientListener?.disable()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        orientMode = 0
        updateMini()
    }

    private fun updateMini() {
        val c = current
        if (c != null && c.audio) {
            miniBar.visibility = View.VISIBLE
            miniTitle.text = c.title
            setPlayIcons(player.isPlaying)
        } else {
            miniBar.visibility = View.GONE
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26 && playerScreen.visibility == View.VISIBLE) {
            showControls(false)
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (e: Exception) {
                Toast.makeText(this, "PiP is not supported on this phone", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // =====================================================================
    // Playback
    // =====================================================================

    private fun onPlayerEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.LengthChanged -> {
                length = e.lengthChanged
                lengthText.text = fmt(length)
                seek.max = (length / 1000).toInt()
            }
            MediaPlayer.Event.TimeChanged -> {
                if (!userSeeking) {
                    seek.progress = (e.timeChanged / 1000).toInt()
                    timeText.text = fmt(e.timeChanged)
                }
                val now = System.currentTimeMillis()
                if (now - lastSave > 5000L) {
                    lastSave = now
                    saveProgress()
                }
            }
            MediaPlayer.Event.Playing -> {
                setPlayIcons(true)
                if (pendingSeek > 0L) {
                    player.setTime(pendingSeek)
                    pendingSeek = 0L
                }
                player.setVolume(volPct)
                if (current?.audio == true) startBgService()
            }
            MediaPlayer.Event.Paused -> {
                setPlayIcons(false)
                stopBgService()
            }
            MediaPlayer.Event.Stopped -> {
                setPlayIcons(false)
            }
            MediaPlayer.Event.EndReached -> handler.post { onEnded() }
            MediaPlayer.Event.EncounteredError -> {
                Toast.makeText(this, "This file could not be played", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startQueue(items: List<Item>, index: Int) {
        queue = items
        playAt(index)
    }

    private fun playAt(i: Int) {
        if (i < 0 || i >= queue.size) return
        saveProgress()
        qIndex = i
        val item = queue[i]
        val local = item.uri.scheme == "content" || item.uri.scheme == "file"
        pendingSeek = if (local) prefs.getLong("pos_" + item.uri.toString(), 0L) else 0L
        if (!openMedia(item.uri)) return
        current = item
        pushRecent(item)
        titleText.text = item.title
        audioArt.visibility = if (item.audio) View.VISIBLE else View.GONE
        player.setRate(1f)
        applyScale(scaleIdx, false)
        showPlayer()
        updateMini()
    }

    private fun openMedia(uri: Uri): Boolean {
        return try {
            pfd?.close()
            pfd = null
            val media: Media
            if (uri.scheme == "content" || uri.scheme == "file") {
                pfd = contentResolver.openFileDescriptor(uri, "r")
                media = Media(libVLC, pfd!!.fileDescriptor)
            } else {
                media = Media(libVLC, uri)
            }
            player.setMedia(media)
            media.release()
            player.play()
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file", Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun onEnded() {
        current?.let { prefs.edit().remove("pos_" + it.uri.toString()).apply() }
        when {
            repeatMode == 2 -> playAt(qIndex)
            shuffle && queue.size > 1 -> playAt(randomIndex())
            qIndex + 1 < queue.size -> playAt(qIndex + 1)
            repeatMode == 1 && queue.isNotEmpty() -> playAt(0)
            else -> {
                setPlayIcons(false)
                stopBgService()
                showControls(true)
            }
        }
    }

    private fun randomIndex(): Int {
        var r = (0 until queue.size).random()
        if (queue.size > 1) {
            while (r == qIndex) r = (0 until queue.size).random()
        }
        return r
    }

    private fun next() {
        if (queue.isEmpty()) return
        if (shuffle && queue.size > 1) playAt(randomIndex())
        else if (qIndex + 1 < queue.size) playAt(qIndex + 1)
        else if (repeatMode == 1) playAt(0)
        else showOsd("Last item")
    }

    private fun prev() {
        if (queue.isEmpty()) return
        if (player.getTime() > 3000L) player.setTime(0L)
        else if (qIndex > 0) playAt(qIndex - 1)
        else if (repeatMode == 1) playAt(queue.size - 1)
        else player.setTime(0L)
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun seekBy(ms: Long) {
        var t = player.getTime() + ms
        if (t < 0L) t = 0L
        val len = player.getLength()
        if (len > 0L && t > len) t = len
        player.setTime(t)
        showOsd((if (ms > 0) "+" else "-") + abs(ms / 1000) + "s")
    }

    private fun saveProgress() {
        val c = current ?: return
        if (c.uri.scheme != "content" && c.uri.scheme != "file") return
        val len = player.getLength()
        if (len <= 0L) return
        val t = player.getTime()
        val e = prefs.edit()
        val key = "pos_" + c.uri.toString()
        if (t > 5000L && t < len - 5000L) e.putLong(key, t) else e.remove(key)
        e.apply()
    }

    private fun applyScale(i: Int, announce: Boolean = true) {
        when (i) {
            0 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT)
            1 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
            2 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL)
            3 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_16_9)
            4 -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_4_3)
            else -> player.setVideoScale(MediaPlayer.ScaleType.SURFACE_ORIGINAL)
        }
        if (announce) showOsd(scaleNames[i], R.drawable.ic_aspect)
    }

    // =====================================================================
    // Dialogs and extras
    // =====================================================================

    private fun choose(title: String, options: Array<String>, checked: Int, onPick: (Int) -> Unit) {
        val b = AlertDialog.Builder(this).setTitle(title)
        if (checked >= 0) {
            b.setSingleChoiceItems(options, checked) { d, i ->
                onPick(i)
                d.dismiss()
            }
        } else {
            b.setItems(options) { _, i -> onPick(i) }
        }
        b.show()
    }

    private fun pickTrack(
        title: String,
        tracks: Array<MediaPlayer.TrackDescription>?,
        current: Int,
        onPick: (Int) -> Unit
    ) {
        if (tracks == null || tracks.isEmpty()) {
            Toast.makeText(this, "No track found", Toast.LENGTH_SHORT).show()
            return
        }
        val names = Array(tracks.size) { tracks[it].name ?: "Track" }
        val checked = tracks.indexOfFirst { it.id == current }
        choose(title, names, if (checked < 0) 0 else checked) { onPick(tracks[it].id) }
    }

    private fun speedDialog() {
        val names = Array(speeds.size) { speeds[it].toString().removeSuffix(".0") + "x" }
        val cur = speeds.indexOfFirst { it == player.getRate() }
        choose("Speed", names, if (cur < 0) 3 else cur) {
            player.setRate(speeds[it])
        }
    }

    private fun sleepDialog() {
        val opts = arrayOf("Off", "15 min", "30 min", "45 min", "60 min", "90 min")
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        choose("Sleep timer", opts, -1) { i ->
            sleepRunnable?.let { handler.removeCallbacks(it) }
            sleepRunnable = null
            if (mins[i] > 0) {
                val r = Runnable {
                    player.pause()
                    showOsd("Sleep timer: paused", R.drawable.ic_sleep)
                }
                sleepRunnable = r
                handler.postDelayed(r, mins[i] * 60000L)
                showOsd("Off in " + mins[i].toString() + " min", R.drawable.ic_sleep)
            } else {
                showOsd("Sleep timer off")
            }
        }
    }

    private fun moreDialog() {
        val rate = player.getRate().toString().removeSuffix(".0") + "x"
        val repLabel = arrayOf("Repeat: Off", "Repeat: All", "Repeat: One")[repeatMode]
        val repIcon = intArrayOf(
            R.drawable.ic_repeat_off, R.drawable.ic_repeat, R.drawable.ic_repeat_one
        )[repeatMode]
        iconMenu("More", listOf(
            MenuRow(R.drawable.ic_lock, "Lock screen") { setLocked(true) },
            MenuRow(R.drawable.ic_pip, "Picture in picture") { enterPip() },
            MenuRow(R.drawable.ic_volume, "Audio track") {
                pickTrack("Audio track", player.getAudioTracks(), player.getAudioTrack()) {
                    player.setAudioTrack(it)
                }
            },
            MenuRow(0, "Speed", rate) { speedDialog() },
            MenuRow(R.drawable.ic_sleep, "Sleep timer") { sleepDialog() },
            MenuRow(R.drawable.ic_shuffle, "Shuffle: " + (if (shuffle) "On" else "Off")) {
                shuffle = !shuffle
                showOsd(if (shuffle) "Shuffle ON" else "Shuffle OFF", R.drawable.ic_shuffle)
            },
            MenuRow(repIcon, repLabel) {
                repeatMode = (repeatMode + 1) % 3
                showOsd(arrayOf("Repeat OFF", "Repeat ALL", "Repeat ONE")[repeatMode], repIcon)
            },
            MenuRow(R.drawable.ic_subtitles, "Load subtitle file") { pickSubtitle() },
            MenuRow(R.drawable.ic_subtitles, "Subtitle delay") { delayDialog(false) },
            MenuRow(R.drawable.ic_volume, "Audio delay") { delayDialog(true) },
            MenuRow(R.drawable.ic_music, "Equalizer") { equalizerDialog() }
        ))
    }

    private fun delayDialog(audio: Boolean) {
        val base = if (audio) player.getAudioDelay() else player.getSpuDelay()
        val label = (if (audio) "Audio" else "Subtitle") + " delay: " + (base / 1000) + " ms"
        choose(label, arrayOf("-100 ms", "+100 ms", "Reset"), -1) { i ->
            val nv = when (i) {
                0 -> base - 100000L
                1 -> base + 100000L
                else -> 0L
            }
            if (audio) player.setAudioDelay(nv) else player.setSpuDelay(nv)
            delayDialog(audio)
        }
    }

    private fun equalizerDialog() {
        val n = MediaPlayer.Equalizer.getPresetCount()
        val names = Array(n + 1) { if (it == 0) "Off" else MediaPlayer.Equalizer.getPresetName(it - 1) }
        choose("Equalizer", names, -1) { i ->
            if (i == 0) player.setEqualizer(null)
            else player.setEqualizer(MediaPlayer.Equalizer.createFromPreset(i - 1))
            showOsd("Equalizer: " + names[i])
        }
    }

    // 0 = Auto (gyro: portrait + dono landscape, ulta portrait band), 1 = Landscape lock, 2 = Portrait lock
    private fun cycleOrientation() {
        orientMode = (orientMode + 1) % 3
        when (orientMode) {
            0 -> startAutoRotate()
            1 -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        showOsd(arrayOf("Auto rotate", "Landscape", "Portrait")[orientMode], R.drawable.ic_rotate)
    }

    private fun startAutoRotate() {
        if (orientListener == null) {
            orientListener = object : OrientationEventListener(this) {
                override fun onOrientationChanged(o: Int) {
                    if (o == OrientationEventListener.ORIENTATION_UNKNOWN || orientMode != 0) return
                    val want = when {
                        o >= 330 || o <= 30 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        o in 240..300 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        o in 60..120 -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                        else -> return // ulta portrait (150-210) aur beech ke angle: kuch mat badlo
                    }
                    if (requestedOrientation != want) requestedOrientation = want
                }
            }
        }
        val l = orientListener!!
        if (l.canDetectOrientation()) l.enable()
        else requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    // =====================================================================
    // File pickers
    // =====================================================================

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
        startActivityForResult(i, REQ_OPEN)
    }

    private fun pickSubtitle() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, REQ_SUB)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQ_OPEN) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            handleViewUri(uri)
        } else if (requestCode == REQ_SUB) {
            addSubtitle(uri)
        }
    }

    private fun handleViewUri(uri: Uri) {
        val audio = (contentResolver.getType(uri) ?: "").startsWith("audio")
        val name = queryName(uri)
        startQueue(listOf(Item(uri, name.substringBeforeLast('.'), "File", audio, 0L, 0L, 0L)), 0)
    }

    private fun queryName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (n != null) return n
                }
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "Video"
    }

    private fun addSubtitle(uri: Uri) {
        try {
            val ext = queryName(uri).substringAfterLast('.', "srt")
            val f = File(cacheDir, "sub_" + System.currentTimeMillis() + "." + ext)
            contentResolver.openInputStream(uri)?.use { inp ->
                f.outputStream().use { out -> inp.copyTo(out) }
            }
            player.addSlave(IMedia.Slave.Type.Subtitle, Uri.fromFile(f), true)
            showOsd("Subtitle loaded")
        } catch (e: Exception) {
            Toast.makeText(this, "Subtitle failed to load", Toast.LENGTH_SHORT).show()
        }
    }

    // =====================================================================
    // Background service + helpers
    // =====================================================================

    private fun startBgService() {
        try {
            val i = Intent(this, PlayService::class.java)
            i.putExtra("title", current?.title ?: "VPlayer")
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
        }
    }

    private fun stopBgService() {
        try {
            stopService(Intent(this, PlayService::class.java))
        } catch (e: Exception) {
        }
    }

    private fun fmt(ms: Long): String {
        val s = if (ms < 0L) 0L else ms / 1000L
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
        else String.format("%02d:%02d", m, sec)
    }

    private fun humanSize(b: Long): String {
        return when {
            b >= 1000000000L -> String.format("%.1f GB", b / 1e9)
            b >= 1000000L -> String.format("%.0f MB", b / 1e6)
            else -> String.format("%.0f KB", b / 1e3)
        }
    }
}
