package com.vishu.vplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class MainActivity : Activity() {

    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var controls: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var playBtn: Button
    private lateinit var speedBtn: Button
    private lateinit var hint: TextView

    private var pfd: ParcelFileDescriptor? = null
    private var pending: Uri? = null
    private var length = 0L
    private var userSeeking = false
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private var speedIdx = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        libVLC = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        player = MediaPlayer(libVLC)
        buildUi()
        setContentView(rootView)

        player.setEventListener(MediaPlayer.EventListener { e ->
            runOnUiThread {
                when (e.type) {
                    MediaPlayer.Event.LengthChanged -> {
                        length = e.lengthChanged
                        seek.max = (length / 1000).toInt()
                    }
                    MediaPlayer.Event.TimeChanged -> {
                        if (!userSeeking) {
                            seek.progress = (e.timeChanged / 1000).toInt()
                            timeText.text = fmt(e.timeChanged) + " / " + fmt(length)
                        }
                    }
                    MediaPlayer.Event.Playing -> playBtn.text = "⏸"
                    MediaPlayer.Event.Paused,
                    MediaPlayer.Event.Stopped,
                    MediaPlayer.Event.EndReached -> playBtn.text = "▶"
                }
            }
        })

        if (intent?.action == Intent.ACTION_VIEW) pending = intent.data
    }

    private lateinit var rootView: FrameLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun makeBtn(row: LinearLayout, label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 14f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(0, 0, 0, 0)
        b.setOnClickListener { action() }
        row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return b
    }

    private fun buildUi() {
        rootView = FrameLayout(this)
        rootView.setBackgroundColor(Color.BLACK)

        videoLayout = VLCVideoLayout(this)
        rootView.addView(
            videoLayout,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        videoLayout.setOnClickListener { toggleControls() }

        hint = TextView(this)
        hint.text = "📂 dabao aur video / song chuno"
        hint.setTextColor(Color.LTGRAY)
        hint.textSize = 16f
        rootView.addView(
            hint,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setBackgroundColor(0xAA000000.toInt())
        controls.setPadding(dp(8), dp(8), dp(8), dp(12))

        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) timeText.text = fmt(p * 1000L) + " / " + fmt(length)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                userSeeking = false
                player.time = (s?.progress ?: 0) * 1000L
            }
        })
        controls.addView(seek)

        timeText = TextView(this)
        timeText.text = "00:00 / 00:00"
        timeText.setTextColor(Color.WHITE)
        timeText.gravity = Gravity.CENTER
        controls.addView(timeText)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        makeBtn(row, "📂") { openPicker() }
        makeBtn(row, "-10") { player.time = maxOf(0L, player.time - 10000L) }
        playBtn = makeBtn(row, "▶") { if (player.isPlaying) player.pause() else player.play() }
        makeBtn(row, "+10") { player.time = player.time + 10000L }
        makeBtn(row, "🔊") {
            pickTrack("Audio track", player.audioTracks, player.audioTrack) { player.audioTrack = it }
        }
        makeBtn(row, "CC") {
            pickTrack("Subtitles", player.spuTracks, player.spuTrack) { player.spuTrack = it }
        }
        speedBtn = makeBtn(row, "1x") { cycleSpeed() }
        controls.addView(row)

        rootView.addView(
            controls,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
    }

    private fun toggleControls() {
        controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun cycleSpeed() {
        speedIdx = (speedIdx + 1) % speeds.size
        player.rate = speeds[speedIdx]
        speedBtn.text = speeds[speedIdx].toString().removeSuffix(".0") + "x"
    }

    private fun pickTrack(
        title: String,
        tracks: Array<MediaPlayer.TrackDescription>?,
        current: Int,
        onPick: (Int) -> Unit
    ) {
        if (tracks == null || tracks.isEmpty()) {
            Toast.makeText(this, "Koi track nahi mila", Toast.LENGTH_SHORT).show()
            return
        }
        val names = tracks.map { it.name }.toTypedArray()
        val checked = tracks.indexOfFirst { it.id == current }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(names, checked) { d, i ->
                onPick(tracks[i].id)
                d.dismiss()
            }
            .show()
    }

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.data?.let { playUri(it) }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_VIEW) intent.data?.let { playUri(it) }
    }

    private fun playUri(uri: Uri) {
        try {
            pfd?.close()
            pfd = contentResolver.openFileDescriptor(uri, "r")
            val media = Media(libVLC, pfd!!.fileDescriptor)
            player.media = media
            media.release()
            player.play()
            hint.visibility = View.GONE
            speedIdx = 2
            speedBtn.text = "1x"
        } catch (e: Exception) {
            Toast.makeText(this, "File nahi khul payi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
        else String.format("%02d:%02d", m, sec)
    }

    override fun onStart() {
        super.onStart()
        player.attachViews(videoLayout, null, true, false)
        pending?.let {
            playUri(it)
            pending = null
        }
    }

    override fun onStop() {
        super.onStop()
        player.pause()
        player.detachViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        player.stop()
        player.release()
        libVLC.release()
        pfd?.close()
    }
}
