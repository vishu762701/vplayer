package com.vishu.vplayer

/**
 * UI ke saare size (dp) yahin se badalte hain. Koi bhi number badlo, poori app me badal jaayega.
 *
 * PLAYER SCREEN (upar se neeche):
 *   TOP BAR      : [ic_back]  Title ..........................
 *   (beech me)   : video / gestures (swipe, double tap)
 *   [unlock]     : sirf lock ke time, right side beech me
 *   BOTTOM BAR   : 00:00 ........................... 46:45      <- time row
 *                  =========o============================      <- seekbar (orange)
 *                  [subtitles][rotate]   (PLAY)   [aspect][more]  <- 5 buttons
 *
 * 3-dot (ic_more) ke andar: Lock, PiP, Audio track, Speed, Sleep timer,
 *                           Shuffle, Repeat, Subtitle file, Subtitle delay,
 *                           Audio delay, Equalizer
 *
 * MAIN PAGE (VLC jaisa) - upar se neeche:
 *   TOOLBAR : [logo] eve .................. [search] [resume] [3-dot]
 *             (folder / History ke andar: [back] naam)
 *   SEARCH  : search icon dabane par khulta hai
 *   TABS    : VIDEOS | PLAYLISTS  (sirf Video page ke top pe)
 *   GRID    : folder cards (2x2 mosaic thumbnail + naam + "N videos" + 3-dot)
 *             folder kholo -> video cards (thumbnail + duration + naam + size)
 *   FAB     : orange play button (sab play)
 *   MINI    : gaane ka naam ............... [ic_play / ic_pause]
 *   NAV     : Video | Audio | Browse | Playlists | More
 */
object Ui {
    // VLC jaisa: icon 24dp, touch area 48dp
    const val BTN = 48
    const val ICON = 24

    // play / pause bada button
    const val PLAY_BTN = 56
    const val PLAY_ICON = 44

    // library ke chhote hisse
    const val MINI_BTN = 44
    const val TAB_ICON = 20
    const val ROW_ICON = 24
    const val SEARCH_ICON = 20

    // OSD (swipe karte time screen pe dikhne wala text)
    const val OSD_ICON = 28

    // 3-dot menu ki har line
    const val MENU_ROW_H = 52
    const val MENU_ICON = 24

    // player ke bars
    const val BAR_ALPHA = 170          // 0 = bilkul clear, 255 = pura kala
    const val BAR_PAD_H = 12
    const val BAR_PAD_TOP = 6
    const val BAR_PAD_BOTTOM = 10
    const val TIME_TEXT_SP = 13f
    const val TITLE_TEXT_SP = 16f

    // audio file chalne pe beech ka bada music icon
    const val AUDIO_ART = 160

    // ================= MAIN PAGE (VLC ke screenshot se naapa hua) =================
    // Sab dp me (phone 360dp chauda maana hai). Number badlo -> size badal jayega.

    // ---- toolbar: [logo] eve ............ [search] [resume] [3-dot] ----
    const val APP_NAME = "eve"          // VLC ki jagah jo naam dikhta hai (chhote akshar)
    const val TOOLBAR_H = 56            // toolbar ki oonchai
    const val TOOLBAR_PAD_START = 18    // screen ke left se logo tak
    const val LOGO_W = 28               // logo ka box (chauda)
    const val LOGO_H = 30               // logo ka box (oonchai)
    const val TITLE_GAP = 8             // logo ke baad naam tak ka gap
    const val TITLE_SP = 20f            // naam ka text size
    const val TB_MORE_W = 40            // sabse right wale 3-dot button ki chaudai (VLC me thoda patla)

    // ---- top tabs: VIDEOS | PLAYLISTS ----
    const val TAB_H = 48                // tab row ki oonchai
    const val TAB_TEXT_SP = 14f
    const val TAB_PAD_H = 12            // text ke dono taraf ka gap (underline text jitni chaudi)
    const val TAB_IND_H = 3             // neeche orange line ki motai

    // ---- cards (folder / video) ----
    const val GRID_PAD_H = 20           // screen ke left/right se cards tak
    const val GRID_PAD_TOP = 16         // tabs se pehli row tak
    const val GRID_PAD_BOTTOM = 96      // aakhri row ke neeche (FAB ke liye jagah)
    const val GRID_GAP = 24             // cards ke beech ka gap (aade + khade dono)
    const val COLS_PORTRAIT = 2         // seedhe phone me ek line me kitne cards
    const val COLS_LANDSCAPE = 4        // ulte phone me
    const val THUMB_W = 16              // thumbnail ratio 16:10
    const val THUMB_H = 10
    const val THUMB_RADIUS = 4          // thumbnail ke corner ki golai
    const val PLACEHOLDER_ICON = 32     // thumbnail aane se pehle ka icon
    const val CARD_TITLE_SP = 16f       // folder / video ka naam
    const val CARD_TITLE_GAP = 6        // thumbnail aur naam ke beech
    const val CARD_SUB_SP = 12f         // "33 videos" / size
    const val BADGE_SP = 11f            // duration ka chhota box
    const val CARD_MORE_BTN = 32        // thumbnail pe 3-dot ka button
    const val CARD_MORE_TOP = 4         // 3-dot ka upar se gap

    // ---- FAB (orange play button) ----
    const val FAB = 56
    const val FAB_PAD = 12              // bada = andar ka play icon chhota
    const val FAB_MARGIN_END = 12
    const val FAB_MARGIN_BOTTOM = 19

    // ---- bottom nav: Video | Audio | Browse | Playlists | More ----
    const val NAV_H = 56
    const val NAV_ICON = 24
    const val NAV_TEXT_SP = 12f
    const val DIVIDER = 1               // nav ke upar patli line
}
