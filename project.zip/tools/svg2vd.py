import re, sys, xml.etree.ElementTree as ET

NS = "{http://www.w3.org/2000/svg}"

def f(v):
    s = ("%.4f" % v).rstrip("0").rstrip(".")
    return s if s else "0"

def circle(cx, cy, r):
    return "M%s,%s a%s,%s 0 1,0 %s,0 a%s,%s 0 1,0 %s,0" % (
        f(cx - r), f(cy), f(r), f(r), f(2 * r), f(r), f(r), f(-2 * r))

def rect(x, y, w, h, rx, ry):
    if not rx and not ry:
        return "M%s,%s h%s v%s h%s z" % (f(x), f(y), f(w), f(h), f(-w))
    if not ry: ry = rx
    if not rx: rx = ry
    return ("M%s,%s H%s a%s,%s 0 0 1 %s,%s V%s a%s,%s 0 0 1 %s,%s H%s "
            "a%s,%s 0 0 1 %s,%s V%s a%s,%s 0 0 1 %s,%s z") % (
        f(x + rx), f(y), f(x + w - rx), f(rx), f(ry), f(rx), f(ry),
        f(y + h - ry), f(rx), f(ry), f(-rx), f(ry), f(x + rx),
        f(rx), f(ry), f(-rx), f(-ry), f(y + ry), f(rx), f(ry), f(rx), f(-ry))

def convert(svg_text, color="#FFFFFF"):
    root = ET.fromstring(svg_text)
    sw = root.get("stroke-width", "2")
    paths = []
    for el in root.iter():
        tag = el.tag.replace(NS, "")
        if tag == "svg":
            continue
        g = lambda k, d="0": float(el.get(k, d))
        if tag == "path":
            d = el.get("d").strip()
            paths.append(d)
        elif tag == "circle":
            paths.append(circle(g("cx"), g("cy"), g("r")))
        elif tag == "rect":
            paths.append(rect(g("x"), g("y"), g("width"), g("height"), g("rx"), g("ry")))
        elif tag == "line":
            paths.append("M%s,%s L%s,%s" % (f(g("x1")), f(g("y1")), f(g("x2")), f(g("y2"))))
        elif tag in ("polyline", "polygon"):
            nums = [float(n) for n in re.findall(r"-?\d*\.?\d+", el.get("points"))]
            pts = list(zip(nums[0::2], nums[1::2]))
            d = "M" + " L".join("%s,%s" % (f(a), f(b)) for a, b in pts)
            paths.append(d + (" z" if tag == "polygon" else ""))
        else:
            raise SystemExit("unsupported element: " + tag)
    out = ['<vector xmlns:android="http://schemas.android.com/apk/res/android"',
           '    android:width="24dp"', '    android:height="24dp"',
           '    android:viewportWidth="24"', '    android:viewportHeight="24">']
    for d in paths:
        out.append('    <path')
        out.append('        android:pathData="%s"' % d)
        out.append('        android:strokeColor="%s"' % color)
        out.append('        android:strokeWidth="%s"' % sw)
        out.append('        android:strokeLineCap="round"')
        out.append('        android:strokeLineJoin="round" />')
    out.append('</vector>')
    return "\n".join(out) + "\n"

if __name__ == "__main__":
    print(convert(open(sys.argv[1]).read()))
